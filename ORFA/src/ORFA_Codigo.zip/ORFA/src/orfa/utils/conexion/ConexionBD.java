/**
 * 
 */
package orfa.utils.conexion;


/**
 * @author efesan
 * 
 */
public class ConexionBD {
/*
	public static Connection conexionSQLite() {

	Connection cn = null; 
	//String ruta = "/home/efesan/Documentos/EPN/FIS/Semestres/2015A/AppAmbLibres/Proyecto/EspacioTrabajoOrfa/ORFA/src/BD/orfa_database.db";
		try {
			Class.forName("org.sqlite.JDBC");
			cn = DriverManager.getConnection("jdbc:sqlite:orfa_database.db");
			System.out.println("Opened database successfully");
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.out.println("Error databse dont opened");
			System.exit(0);
		}
		return cn;
	}
	
	 public boolean siguiente (ResultSet rs){
		  try { 	
		   return rs.next();
		  }
		  catch(SQLException error ){
		  	return false;
		  } 
		  
		}
		*/
}