package orfa.utils.beans;


public class BeanMaximos {
    private int anio;
    private float maximoAlimentacion;
    private float maximoEducacion;
    private float maximoSalud;
    private float maximoVestimenta;
    private float maximoVivienda;


    public int getAnio() {
        return anio;
    }


    public void setAnio(int anio) {
        this.anio = anio;
    }


    public float getLimAlimentacion() {
        return maximoAlimentacion;
    }


    public void setLimAlimentacion(float limAlimentacion) {
        this.maximoAlimentacion = limAlimentacion;
    }


    public float getLimEduacion() {
        return maximoEducacion;
    }


    public void setLimEduacion(float limEduacion) {
        this.maximoEducacion = limEduacion;
    }


    public float getLimSalud() {
        return maximoSalud;
    }


    public void setLimSalud(float limSalud) {
        this.maximoSalud = limSalud;
    }


    public float getLimVestimenta() {
        return maximoVestimenta;
    }


    public void setLimVestimenta(float limVestimenta) {
        this.maximoVestimenta = limVestimenta;
    }


    public float getLimVivienda() {
        return maximoVivienda;
    }


    public void setLimVivienda(float limVivienda) {
        this.maximoVivienda = limVivienda;
    }
       
    
}
