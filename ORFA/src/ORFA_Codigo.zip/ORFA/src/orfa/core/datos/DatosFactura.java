package orfa.core.datos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 * 
 * @author OMAR S
 */
public class DatosFactura {

	Connection cn;
	Statement s;
	DefaultTableModel modelo = new DefaultTableModel();
	ResultSet rs;
	float totalCategoria;

	public void insertarValorCategoriasFactura(int id_factura, int anio,
			String id_tipo_Categoria, float valor, int usuario,
			int ruc_proveedor) {
		try {
			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "insert into factura(id_factura, ano_factura,tipo_categoria_factura,valor_tipo_categoria, usuario_id_usuario, proveedor_id_proveedor) values ('"
					+ id_factura
					+ "','"
					+ anio
					+ "','"
					+ id_tipo_Categoria
					+ "','"
					+ valor
					+ "','"
					+ usuario
					+ "','"
					+ ruc_proveedor
					+ "');";
			s.executeUpdate(query);
			//s.close();
			//cn.close();

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, ex, "Error", 1);
		}
	}

	public void consultaCategoriasFactura(int usuario) {
		try {
			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "select id_factura, tipo_categoria_factura, valor_tipo_categoria, ";
		} catch (SQLException ex) {
			Logger.getLogger(DatosFactura.class.getName()).log(Level.SEVERE,
					null, ex);
		}

	}
/*
	public DefaultTableModel lista2(int id_usuario, String nombre_categoria) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			// consuta a mostrar
			String query = "select tipo_categoria_factura as 'Categoria' , valor_tipo_categoria as 'Valor' from factura where usuario_id_usuario='"
					+ id_usuario
					+ "'  and tipo_categoria_factura='"
					+ nombre_categoria + "'";
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}
*/
	// creamos la operacion para mostrar datos en una jtable en el jform
	public DefaultTableModel lista(int numero_factura) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			// consuta a mostrar
			String query = "select tipo_categoria_factura as 'Categoria' , valor_tipo_categoria as 'Valor' from factura where id_factura='"
					+ numero_factura + "'";
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}

	public void Borrar(String nombre) {

		try {
			cn = Conexion.enlace(cn);

			Statement s = cn.createStatement();
			String query = "delete from factura where tipo_categoria_factura='"+ nombre + "'";
			s.executeUpdate(query);
			s.close();
			cn.close();
			JOptionPane.showMessageDialog(null, "Eliminado");
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex);
		}
	}

	public float SumaCategorias(int id_usuario, String nombre_categoria) {
		try {

			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "select sum(valor_tipo_categoria) as 'total' from factura where usuario_id_usuario='"
					+ id_usuario
					+ "'  and tipo_categoria_factura='"
					+ nombre_categoria + "'";
			rs = s.executeQuery(query);
			while (rs.next()) {
				totalCategoria = rs.getFloat("total");

			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		return totalCategoria;
	}
	
	public float vivienda(int id_usuario, int id_factura) {
		try {

			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "select sum(valor_tipo_categoria) as 'total' from factura where usuario_id_usuario='"
					+ id_usuario
					+ "'  and tipo_categoria_factura='Vivienda' and id_factura = '"
					+ id_factura
					+ "'";
			rs = s.executeQuery(query);
			while (rs.next()) {
				totalCategoria = rs.getFloat("total");

			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		return totalCategoria;
	}
	
	public float Vestimenta(int id_usuario, int id_factura) {
		try {

			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "select sum(valor_tipo_categoria) as 'total' from factura where usuario_id_usuario='"
					+ id_usuario
					+ "'  and tipo_categoria_factura='Vestimenta' and id_factura = '"
					+ id_factura
					+ "'";
			rs = s.executeQuery(query);
			while (rs.next()) {
				totalCategoria = rs.getFloat("total");

			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		return totalCategoria;
	}
	
	public float Salud(int id_usuario, int id_factura) {
		try {

			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "select sum(valor_tipo_categoria) as 'total' from factura where usuario_id_usuario='"
					+ id_usuario
					+ "'  and tipo_categoria_factura='Salud' and id_factura = '"
					+ id_factura
					+ "'";
			rs = s.executeQuery(query);
			while (rs.next()) {
				totalCategoria = rs.getFloat("total");

			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		return totalCategoria;
	}
	
	public float educacion(int id_usuario, int id_factura) {
		try {

			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "select sum(valor_tipo_categoria) as 'total' from factura where usuario_id_usuario='"
					+ id_usuario
					+ "'  and tipo_categoria_factura='Educacion' and id_factura = '"
					+ id_factura
					+ "'";
			rs = s.executeQuery(query);
			while (rs.next()) {
				totalCategoria = rs.getFloat("total");

			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		return totalCategoria;
	}
	
	public float alimentacion(int id_usuario, int id_factura) {
		try {

			cn = Conexion.enlace(cn);
			s = cn.createStatement();
			String query = "select sum(valor_tipo_categoria) as 'total' from factura where usuario_id_usuario='"
					+ id_usuario
					+ "'  and tipo_categoria_factura='Alimentacion' and id_factura = '"
					+ id_factura
					+ "'";
			rs = s.executeQuery(query);
			while (rs.next()) {
				totalCategoria = rs.getFloat("total");

			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		return totalCategoria;
	}
	
	
}