package orfa.core.datos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 * 
 * @author Inti Poaquiza
 */
public class DatosUsuario {

	// creamos las variables para la conexion
	static Connection cn;
	static Statement s;
	static ResultSet rs;

	// creamos metodo para insertar datos
	public void AgregarUsuario(int id_usuario, int ruc_usuario,
			String nick_usuario, String nombre_usuario,
			String apellido_usuario, String password_usuario,
			double salario_usuario, String correo_usuario) {
		// dentro de try cacht por si los errores
		try {
			Statement s = cn.createStatement();
			String query = "INSERT INTO usuario(id_usuario, ruc_usuario, nick_usuario,nomre_usuario,apellido_usuario,password_usuario,salario_usuario, correo_usuario)values ('"
					+ id_usuario
					+ "','"
					+ ruc_usuario
					+ "','"
					+ nick_usuario
					+ "','"
					+ nombre_usuario
					+ "','"
					+ apellido_usuario
					+ "','"
					+ password_usuario
					+ "','"
					+ salario_usuario
					+ "','"
					+ correo_usuario + "')";
			s.executeUpdate(query);
			s.close();
			cn.close();
			JOptionPane.showMessageDialog(null, "USUARIO INGRESADO CORRECTAMENTE");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

}