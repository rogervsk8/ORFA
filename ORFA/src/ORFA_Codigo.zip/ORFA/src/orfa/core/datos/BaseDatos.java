package orfa.core.datos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class BaseDatos {

	public void crearBD() {
		Connection cn = null;
		Statement stmt = null;
		try {
			cn = Conexion.enlace(cn);
			stmt = cn.createStatement();
			if (stmt.execute("SELECT name FROM sqlite_master")) {
				String sqlTablaUsuario = "CREATE TABLE usuario ("
						+ "id_usuario INTEGER PRIMARY KEY AUTOINCREMENT   NOT NULL ,"
						+ "ruc_usuario CHARACTER(15) NOT NULL ,"
						+ "nick_usuario CHARACTER(20) NOT NULL UNIQUE,"
						+ "nombre_usuario CHARACTER(50) NOT NULL ,"
						+ "apellido_usuario CHARACTER(50) NOT NULL ,"
						+ "password_usuario CHARACTER(20) NOT NULL ,"
						+ "salario_usuario DOUBLE NOT NULL ,"
						+ "correo_usuario CHARACTER(150) NOT NULL ,"
						+ "pregunta_usuario CHARACTER(100) NULL ,"
						+ "respuesta_usuario CHARACTER(100) NULL)";

				String sqlTablaFactura = "CREATE TABLE factura ("
						+ "id_factura INTEGER PRIMARY KEY AUTOINCREMENT   NOT NULL ,"
						+ "usuario_id_usuario INTEGER NOT NULL ," //pk
						+ "proveedor_id_proveedor INTEGER NOT NULL ," //pk
						+ "ano_factura INTEGER NOT NULL ," //pk
						+ "numero_factura INTEGER NOT NULL ,"
						+ "fecha_factura CHARACTER(15) NOT NULL ,"												
						+ "total_vivienda FLOAT ,"
						+ "total_alimentacion FLOAT ,"
						+ "total_salud FLOAT ,"
						+ "total_educacion FLOAT ,"
						+ "total_vestimenta FLOAT ,"
						+ "total_otros FLOAT ,"
						+ "total_iva FLOAT ,"
						+ "total_deducibles FLOAT ,"
						+ "total_factura FLOAT ,"						
						+ "FOREIGN KEY (ano_factura) REFERENCES maximos(id_maximo_ano),"
						+ "FOREIGN KEY (usuario_id_usuario) REFERENCES usuario(id_usuario),"
						+ "FOREIGN KEY (proveedor_id_proveedor) REFERENCES proveedor(id_proveedor))";

				String sqlTablaProveedor = "CREATE TABLE proveedor ("
						+ "id_proveedor INTEGER PRIMARY KEY AUTOINCREMENT   NOT NULL ,"
						+ "ruc_proveedor CHARACTER(15) NOT NULL ,"
						+ "nombre_proveedor CHARACTER(50) NOT NULL ,"
						+ "ciudad_proveedor CHARACTER(30)  ,"
						+ "direccion_proveedor CHARACTER(150)  ,"
						+ "telefono_proveedor INTEGER )";
				
				String sqlTablaMaximos = "CREATE TABLE maximos ("
						+ "id_maximo_ano  INTEGER PRIMARY KEY NOT NULL ,"
						+ "maximo_vivienda FLOAT NOT NULL ,"
						+ "maximo_alimentacion FLOAT NOT NULL ,"
						+ "maximo_salud FLOAT NOT NULL ,"
						+ "maximo_educacion FLOAT NOT NULL ,"
						+ "maximo_vestimenta FLOAT NOT NULL)";				

				stmt.executeUpdate(sqlTablaUsuario);
				stmt.executeUpdate(sqlTablaFactura);
				stmt.executeUpdate(sqlTablaProveedor);
				stmt.executeUpdate(sqlTablaMaximos);
			}
			stmt.close();
			cn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}
}
