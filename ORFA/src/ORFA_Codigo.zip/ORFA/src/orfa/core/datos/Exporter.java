package orfa.core.datos;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import javax.swing.JTable;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

/**
 *
 * @author IdlhDeveloper
 */
public class Exporter {
    private File file;
    private List<JTable> tabla;
    private List<String> nom_files;

    public Exporter(File file, List<JTable> tabla, List<String> nom_files) throws Exception {
        this.file = file;
        this.tabla = tabla;
        this.nom_files = nom_files;
    if(nom_files.size()!=tabla.size()){
        throw new Exception("Error");
    }
    }
    public boolean export() {
        try {
            DataOutputStream out = new DataOutputStream(new FileOutputStream(file));
            WritableWorkbook w = Workbook.createWorkbook(out);
            for (int index = 0; index < tabla.size(); index++) {
                JTable table = tabla.get(index);
                WritableSheet s = w.createSheet(nom_files.get(index), 0);
                if(table.getColumnCount()==4)
                {
                    s.addCell(new Label(0, 0, "Categoria"));
                    s.addCell(new Label(1, 0, "Total en este a�o"));
                    s.addCell(new Label(2, 0, "Limite"));
                    s.addCell(new Label(3, 0, "Limite - Gastado"));
                }
                else
                {
                	s.addCell(new Label(0, 0, "Num Factura"));
                    s.addCell(new Label(1, 0, "Proveedor"));
                    s.addCell(new Label(2, 0, "Fecha"));
                    s.addCell(new Label(3, 0, "Vivienda"));
                    s.addCell(new Label(4, 0, "Alimentacion"));
                    s.addCell(new Label(5, 0, "Salud"));
                    s.addCell(new Label(6, 0, "Educacion"));
                    s.addCell(new Label(7, 0, "Vestimenta"));
                    s.addCell(new Label(8, 0, "Otros"));
                    s.addCell(new Label(9, 0, "IVA"));
                    s.addCell(new Label(10, 0, "Total sin IVA"));
                    s.addCell(new Label(11, 0, "Total con IVA"));
                }
                for (int i = 0; i < table.getColumnCount(); i++) {
                    for (int j = 0; j < table.getRowCount(); j++) {
                        Object object = table.getValueAt(j, i);
                        s.addCell(new Label(i, j+1, String.valueOf(object)));
                    }
                }
            }
            w.write();
            w.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}