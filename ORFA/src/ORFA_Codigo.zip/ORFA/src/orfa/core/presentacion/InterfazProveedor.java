
package orfa.core.presentacion;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ListSelectionModel;

import java.awt.ScrollPane;

import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;

import orfa.utils.beans.BeanFactura;
import orfa.utils.beans.BeanUsuario;
import orfa.utils.conexion.ConexionBD;
import orfa.utils.beans.BeanProveedor;
import orfa.core.datos.OperacionesSQLite;


public class InterfazProveedor extends javax.swing.JFrame {

	
	BeanProveedor proveedor = new BeanProveedor();
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtRuc;
	private JTextField txtDireccion;
	private JTextField txtTelefono;
	private JTextField txtCiudad;
	private JTable jtbProveedor;
	private String strRazonSocial, strRUC, strDireccion, strTelefono, strCiudad, StrIdProveedor="";
	int filas=0;
        ResultSet result;
	private Object [] datos = new Object[5];

	DefaultTableModel modelo = new modelo1();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfazProveedor frame = new InterfazProveedor();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public InterfazProveedor() {
		setTitle("Proveedor");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//setLocationRelativeTo(null);
		
		setBounds(100, 100, 594, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		txtNombre = new JTextField();
		txtNombre.setBounds(250, 26, 200, 21);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);

		txtRuc = new JTextField();
		txtRuc.setBounds(250, 57, 200, 21);
		contentPane.add(txtRuc);
		txtRuc.setColumns(10);
		txtRuc.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtRuc.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});		

		txtDireccion = new JTextField();
		txtDireccion.setBounds(250, 91, 200, 21);
		contentPane.add(txtDireccion);
		txtDireccion.setColumns(10);

		txtTelefono = new JTextField();
		txtTelefono.setBounds(250, 122, 200, 21);
		contentPane.add(txtTelefono);
		txtTelefono.setColumns(10);
		txtTelefono.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTelefono.getText().length()== 10)		    	  
		    	     e.consume();
		    	}
		   }
		});

		JLabel lblNewLabel = new JLabel("Nombre/Razon Social:");
		lblNewLabel.setBounds(100, 29, 156, 14);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("RUC");
		lblNewLabel_1.setBounds(100, 63, 156, 14);
		contentPane.add(lblNewLabel_1);
		

		JLabel lblNewLabel_2 = new JLabel("Direccion");
		lblNewLabel_2.setBounds(100, 94, 156, 14);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Telefono");
		lblNewLabel_3.setBounds(100, 125, 156, 14);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Ciudad");
		lblNewLabel_4.setBounds(100, 156, 156, 14);
		contentPane.add(lblNewLabel_4);

		txtCiudad = new JTextField();
		txtCiudad.setBounds(250, 153, 200, 21);
		contentPane.add(txtCiudad);
		txtCiudad.setColumns(10);

                
                
		JButton btnNewButton = new JButton("Ingresar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//txtRuc.setEnabled(true);
				String strErrores="";
				String strErrores1="";
				String strErrores2="";
				String strAux;

				//validacion telefono
				if(txtTelefono.getText().length()<7 && txtTelefono.getText().length()!=0)
				{
					strErrores+="Telefono invalido, ingreselo de nuevo\n";
				}
				else
				{
					if(txtTelefono.getText().length()>10)
					{
						strErrores+="Telefono: Numero de caracteres superado, maximo 10 caracteres, no se permiten espacios\n";
					}
					if(!txtTelefono.getText().matches("(([0-9]){1,10})$"))//Comprueba con una expresion regular si esque se ha ingresado un simbolo o caracter especial, 
					{              																   
						//strErrores+="Telefono: Ha ingresado simbolos o letras, ingresar solo numeros\n"; //se llena la variable de errores								
					}
				}

				//limpiar variables para reutilizar
				strErrores2="";


				//validacion direccion
				if(txtCiudad.getText().length()==0)
				{
					//strErrores+="Ingresar Ciudad\n";
				}
				else
				{
					if(txtCiudad.getText().length()>25)
					{
						strErrores+="Ciudad: Numero de caracteres superado, maximo 25 caracteres\n";
					}
					for (int i=0; i<=(txtCiudad.getText().length()-1); i++ )// empieza a comprobar si no existen numeros en vez de letras, valido para Nombres Y Apellidos
					{
						String strAux1=txtCiudad.getText().substring(i, i+1);
						if(i<(txtCiudad.getText().length()-1))
						{
							if(strAux1.equals(txtCiudad.getText().substring(i+1, i+2))&&strAux1.equals(" "))
							{		
								strErrores2+="y";
							}
						}
					}
				}
				if(strErrores2.length()>0)
				{
					//strErrores+="Ciudad: Ha digitado espacios seguidos, valido solo un espacio entre palabras\n";
				}

				//limpiar variables para reutilizar
				strErrores1="";
				strErrores2="";
				strAux="";

				//validacion total y muestra de errores
				if(strErrores.length()>0)
				{
					JOptionPane.showMessageDialog(null, strErrores, "Registro de Proveedor", JOptionPane.ERROR_MESSAGE);
					return;
				}
				else
				{
					strRazonSocial=txtNombre.getText();
					strDireccion=txtDireccion.getText();
					strRUC=txtRuc.getText();
					strTelefono=txtTelefono.getText();
					strCiudad=txtCiudad.getText();

					//toma del RUC del txt
					String ruc_dato = txtRuc.getText();
      
//***************************************************************************************************************************
					//ingreso a la base de datos
					
					//Insertar y Actualizar datos
					if( StrIdProveedor.equals(""))
					{
						if (ruc_dato.length()==13 && validarRUC(ruc_dato)==true)
						{
							//System.out.println("El RUC es correcto");

            						BeanProveedor bp = new BeanProveedor();
                                    bp.setRucProveedor(strRUC);
                    				bp.setNombreProveedor(strRazonSocial);
                        			bp.setCiudadProveedor(strCiudad);
                                	bp.setDireccionProveedor(strDireccion);
                                    bp.setTelefonoProveedor(strTelefono);
                                    
                                    if(txtRuc.isEnabled()== true && txtCiudad.isEnabled()== true)
                                    {
                                    	OperacionesSQLite.insertarProveedor(bp);
                                    }
                                    if(txtRuc.isEnabled()== false && txtCiudad.isEnabled()== true)
                                    {
                                    	//JOptionPane.showMessageDialog(null, "ruc desabilitaddo");
                                    	OperacionesSQLite.actualizarProveedor(bp);                                    	
                                    }
                                    limpiar();
                                    Datos();
                                                
                                                
                        }
						else
						{
							JOptionPane.showMessageDialog(null, "El RUC ingresado es incorrecto", "Registro de Proveedor",JOptionPane.INFORMATION_MESSAGE);
							System.out.println("El RUC es incorrecto");
                                                }
					}
					else
					{
						
						BeanProveedor bp = new BeanProveedor();
						DefaultTableModel model = new DefaultTableModel();
						bp.setRucProveedor(strRUC);
						bp.setNombreProveedor(strRazonSocial);
						bp.setCiudadProveedor(strCiudad);
						bp.setDireccionProveedor(strDireccion);
						bp.setTelefonoProveedor(strTelefono);
						jtbProveedor.setModel(model);
						//OperacionesSQLite.actualizarProveedor(bp);
						jtbProveedor.changeSelection(0, 0, false, true);                    
						JOptionPane.showMessageDialog(null, "Error 2");
					}

				}
				Datos();
			}
		});
		
		btnNewButton.setBounds(25, 224, 128, 35);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Nuevo");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				limpiar();

			}
		});
		
		btnNewButton_1.setBounds(175, 223, 124, 37);
		contentPane.add(btnNewButton_1);

		datos[0]="Nombre/Razon Social";
		datos[1]="RUC";
		datos[2]="Direccion";
		datos[3]="Telefono";
		datos[4]="Ciudad";
                
                for(int i=0; i<5;i++){
			modelo.addColumn(datos[i]);
		}

                
		JButton btnNewButton_2 = new JButton("Eliminar");
		btnNewButton_2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				//txtRuc.setEnabled(true);
                                strRUC=txtRuc.getText();
                                if (strRUC.length()==13){
                                    OperacionesSQLite.eliminarProveedor(strRUC);
                                    limpiar();
                                   // remover();
                                    Datos();
                                }
                                else{
                                    JOptionPane.showMessageDialog(null, "El RUC ingresado es incorrecto", "Eliminar Proveedor",JOptionPane.INFORMATION_MESSAGE);
                                }
                                Datos();
			}

		});
               
		
		btnNewButton_2.setBounds(316, 224, 112, 35);
		contentPane.add(btnNewButton_2);

                
                JButton btnActualizar = new JButton("Editar");
		btnActualizar.addActionListener(new ActionListener() {
                		public void actionPerformed(ActionEvent arg0) {
                                    
            				txtNombre.setEnabled(true);
            				txtRuc.setEnabled(false);
            				txtDireccion.setEnabled(true);
            				txtTelefono.setEnabled(true);
            				txtCiudad.setEnabled(true);
				Datos();}
                
                });
                btnActualizar.setBounds(445, 224, 112, 35);
		contentPane.add(btnActualizar);
                
                
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Funciones("salir");
			}
		});
		
		btnSalir.setBounds(441, 224, 100, 35);
		//contentPane.add(btnSalir);

 
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 290, 560, 130);
		contentPane.add(scrollPane);
		
		
                jtbProveedor = new JTable();
		scrollPane.setViewportView(jtbProveedor);

		jtbProveedor.setModel(new DefaultTableModel(
				new Object[][] {
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
				},
				new String[] {
						"Nombre/Razon Social", "RUC", "Direccion", "Telefono", "Ciudad"
				}
				));
                
                
                jtbProveedor.setModel(modelo);
                jtbProveedor.getSelectionModel().addListSelectionListener(new InterfazProveedor.RowListener());
		         Datos();

		JLabel lblNewLabel_5 = new JLabel("  ");
		//lblNewLabel_5.setIcon(new ImageIcon(InterfazProveedor.class.getResource("/imagenes/proveedor.png")));
		lblNewLabel_5.setBounds(316, 5, 225, 208);
		contentPane.add(lblNewLabel_5);

	}
	
	 public void Datos()
	    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    jtbProveedor.setModel(new DefaultTableModel());
	    model = op.listaProveedor();
	    jtbProveedor.setModel(model);
	    }
	     


	public void limpiar(){
		txtCiudad.setText("");
		txtDireccion.setText("");
		txtNombre.setText("");
		txtTelefono.setText("");
		txtRuc.setText("");
		txtRuc.setEnabled(true);
		txtNombre.setEnabled(true);
		txtDireccion.setEnabled(true);
		txtTelefono.setEnabled(true);
		txtCiudad.setEnabled(true);
        
	}
        
     	class RowListener implements ListSelectionListener {
		public void valueChanged(ListSelectionEvent event) {
		
			try{

				int renglon = jtbProveedor.getSelectedRow();
				modelo.isCellEditable(renglon, 0);
				modelo.isCellEditable(renglon, 1);
				modelo.isCellEditable(renglon, 2);
				modelo.isCellEditable(renglon, 3);
				modelo.isCellEditable(renglon, 4);

				txtNombre.setText(jtbProveedor.getValueAt(renglon, 1).toString());
				txtRuc.setText(jtbProveedor.getValueAt(renglon, 0).toString());
				txtDireccion.setText(jtbProveedor.getValueAt(renglon, 3).toString());
				txtTelefono.setText(jtbProveedor.getValueAt(renglon,4).toString());
				txtCiudad.setText(jtbProveedor.getValueAt(renglon, 2).toString());

				txtNombre.setEnabled(false);
				txtRuc.setEnabled(false);
				txtDireccion.setEnabled(false);
				txtTelefono.setEnabled(false);
				txtCiudad.setEnabled(false);
				
			}
			catch(Exception e)
			{
				System.out.println("");
			}
			
		}
	}  
	
        
        
	public class modelo1 extends DefaultTableModel
	{
		private static final long serialVersionUID = 1L;//Identificador Unico de la Clase

		public boolean isCellEditable(int row, int column)
		{
			return false;
		}
		public boolean isCellSelectable(int row, int column)
		{
			return true;
		}
	}
	protected void Funciones(String arg0)
	{
		if(arg0.equals("salir"))
		{
			this.setVisible(false);
		}  
	}

	public boolean validarRUC(String ruc) {
		boolean valor = true;
		try {
			int suma = 0;
			int residuo = 0;
			boolean privada = false;
			boolean publica = false;
			boolean natural = false;
			int digitoVerificador = 0;
			int modulo = 11;

			int d1, d2, d3, d4, d5, d6, d7, d8, d9, d10;
			int p1, p2, p3, p4, p5, p6, p7, p8, p9;

			d1 = d2 = d3 = d4 = d5 = d6 = d7 = d8 = d9 = d10 = 0;
			p1 = p2 = p3 = p4 = p5 = p6 = p7 = p8 = p9 = 0;

			// Aqui almacenamos los digitos de la cedula en variables.
			d1 = Integer.parseInt(ruc.substring(0, 1));
			d2 = Integer.parseInt(ruc.substring(1, 2));
			d3 = Integer.parseInt(ruc.substring(2, 3));
			d4 = Integer.parseInt(ruc.substring(3, 4));
			d5 = Integer.parseInt(ruc.substring(4, 5));
			d6 = Integer.parseInt(ruc.substring(5, 6));
			d7 = Integer.parseInt(ruc.substring(6, 7));
			d8 = Integer.parseInt(ruc.substring(7, 8));
			d9 = Integer.parseInt(ruc.substring(8, 9));
			d10 = Integer.parseInt(ruc.substring(9, 10));

			// El tercer digito es:
			// 9 para sociedades privadas y extranjeros
			// 6 para sociedades publicas
			// menor que 6 (0,1,2,3,4,5) para personas naturales
			if (d3 == 7 || d3 == 8) {
				valor = false;
			}

			// Solo para personas naturales (modulo 10)
			if (d3 < 6) {
				natural = true;
				modulo = 10;
				p1 = d1 * 2;
				if (p1 >= 10)
					p1 -= 9;
				p2 = d2 * 1;
				if (p2 >= 10)
					p2 -= 9;
				p3 = d3 * 2;
				if (p3 >= 10)
					p3 -= 9;
				p4 = d4 * 1;
				if (p4 >= 10)
					p4 -= 9;
				p5 = d5 * 2;
				if (p5 >= 10)
					p5 -= 9;
				p6 = d6 * 1;
				if (p6 >= 10)
					p6 -= 9;
				p7 = d7 * 2;
				if (p7 >= 10)
					p7 -= 9;
				p8 = d8 * 1;
				if (p8 >= 10)
					p8 -= 9;
				p9 = d9 * 2;
				if (p9 >= 10)
					p9 -= 9;
			}

			// Solo para sociedades publicas (modulo 11)
			// Aqui el digito verficador esta en la posicion 9, en las otras 2
			// en la pos. 10
			if (d3 == 6) {
				publica = true;
				p1 = d1 * 3;
				p2 = d2 * 2;
				p3 = d3 * 7;
				p4 = d4 * 6;
				p5 = d5 * 5;
				p6 = d6 * 4;
				p7 = d7 * 3;
				p8 = d8 * 2;
				p9 = 0;
			}

			/* Solo para entidades privadas (modulo 11) */
			if (d3 == 9) {
				privada = true;
				p1 = d1 * 4;
				p2 = d2 * 3;
				p3 = d3 * 2;
				p4 = d4 * 7;
				p5 = d5 * 6;
				p6 = d6 * 5;
				p7 = d7 * 4;
				p8 = d8 * 3;
				p9 = d9 * 2;
			}

			suma = p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9;
			residuo = suma % modulo;

			// Si residuo=0, dig.ver.=0, caso contrario 10 - residuo
			digitoVerificador = residuo == 0 ? 0 : modulo - residuo;
			int longitud = ruc.length(); // Longitud del string

			// ahora comparamos el elemento de la posicion 10 con el dig. ver.
			if (publica == true) {
				if (digitoVerificador != d9) {
					valor = false;
				}
				/* El ruc de las empresas del sector publico terminan con 0001 */
				if (!ruc.substring(9, longitud).equals("0001")) {
					valor = false;
				}
			}

			if (privada == true) {
				if (digitoVerificador != d10) {
					valor = false;
				}
				if (!ruc.substring(10, longitud).equals("001")) {
					valor = false;
				}
			}

			if (natural == true) {
				if (digitoVerificador != d10) {
					valor = false;
				}
				if (ruc.length() > 10
						&& !ruc.substring(10, longitud).equals("001")) {
					valor = false;
				}
			}
		} catch (Exception e) {
			valor = false;
		}
		return valor;

	}

}