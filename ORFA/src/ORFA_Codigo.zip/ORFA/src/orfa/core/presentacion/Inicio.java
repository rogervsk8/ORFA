package orfa.core.presentacion;

import java.awt.Color;
import java.awt.Point;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JWindow;

import orfa.core.datos.BaseDatos;
import orfa.core.presentacion.InicioOrfa;

public class Inicio extends JWindow 
{	
	private static final long serialVersionUID = 1L;
	JProgressBar barraDeProgreso;
	@SuppressWarnings({ "static-access", "unused" })
	public Inicio() throws InterruptedException
	{		
	   //La clase Toolkit es una clase que proporciona un interfaz independiente de plataforma para servicios espec�ficos de esas plataformas, como pueden ser: fuentes de caracteres, im�genes, impresi�n y par�metros de pantalla. El constructor de la clase es abstracto y, por lo tanto, no se puede instanciar ning�n objeto de la clase Toolkit; sin embargo, s� que se puede obtener un objeto Toolkit mediante la invocaci�n del m�todo getDefaultToolkit(), que devolver� un objeto de este tipo, adecuado a la plataforma en que se est� ejecutando.

		int w= this.getToolkit().getDefaultToolkit().getScreenSize().width;
		int h= this.getToolkit().getDefaultToolkit().getScreenSize().height;
		int z=2;
		int x= (w-521)/z;
		int y= (h-335)/z;

		JLabel img= new JLabel(new ImageIcon("grafico/factura.JPG"));//la image en la direccion y la extencion que tiene dentro del proyecto
		img.setLocation(new Point(0,-40));//posicion del la imagen dentro del label
		img.setSize(1000,700);//tama�o de la imagen 

		this.setLayout(null);
		this.add(img);
		this.setLocation(new Point(70,70));//x,y posicion del splash
		this.setSize(1000,625);//tama�o del layout   
		this.setVisible(true);
		//

		barraDeProgreso=new JProgressBar();//se crea una barra de progreso solo con borde pero ningun progreso puede estar lleno de 0 hasta 100
		barraDeProgreso.setBackground(new Color(1,2,0));// (red ,gren, blu)combinacion de colores para fondo barra de progreso
		barraDeProgreso.setBounds(0,580,810,30);// los dos primeros determinan la posicion de la barra y los dos siguientes su tama�o
		barraDeProgreso.setStringPainted(true);//muestra el porcentaje de carga
		this.add(barraDeProgreso);

		new Thread()//esta clase es una tarea independiente a otras tareas dentro del programa llamado hilo
		{
			public void run()//metodo que hace que comiense a correr la tarea
			{
				for (int progreso =0; progreso<=100; progreso++)
				{
					//determina el porcentaje de la carga
					try
					{
						barraDeProgreso.setValue(progreso);
						sleep(30);//tiempo que se demora en cargar la barra mas peque�o mas rapido se termina de cargar
					}
					catch (InterruptedException e1)
					{
						e1.printStackTrace();//caso contrario  se sale del programa o imprime la excepcion de la pila generada						
					}
					if (progreso == 100)
					{
	
						InterfazLogin login = new InterfazLogin();
						login.setVisible(true);
					}					
				}
			}			

		}.start(); //este metodo hace que el tread y el run corran al mismo tiempo   (del m�todo start) y el otro hilo (que ejecuta su m�todo run).

		Thread.sleep(3000);//9600 tiempo en el que se demora en desaparecer la imagen el splash

		this.setVisible(false);//hace desaparecer el splash
	}
	public static void main (String Args[]) throws InterruptedException
	{
		new Inicio();
		try {
			new BaseDatos().crearBD();
			//new InterfazLogin().setVisible(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Ha fallado el lanzamiento",
					"Info", JOptionPane.PLAIN_MESSAGE);
		}
	}
}
