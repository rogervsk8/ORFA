package orfa.core.presentacion;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import orfa.core.datos.OperacionesSQLite;
import orfa.core.datos.ValidacionMaximos;
import orfa.utils.beans.BeanUsuario;
public class InterfazMaximos extends javax.swing.JFrame {

	private javax.swing.JButton btmModificar;
	private javax.swing.JButton btmGuardar;
	private javax.swing.JButton btmEliminar;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton btnContinuar;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JSeparator jSeparator2;
	private javax.swing.JTable jTableAnios;
	private javax.swing.JTextField txtAnio;
	private javax.swing.JTextField txtLimConAlimentacion;
	private javax.swing.JTextField txtLimConEducacion;
	private javax.swing.JTextField txtLimConSalud;
	private javax.swing.JTextField txtLimConVestimenta;
	private javax.swing.JTextField txtLimConVivienda;
	BeanUsuario usuarioIC=null;

	public void llenarAnios() {
		OperacionesSQLite op = new OperacionesSQLite();
		DefaultTableModel modelo1 = new DefaultTableModel();
		modelo1 = op.listaAnios();
		jTableAnios.setModel(modelo1);
	}
	public void mensajes(BeanUsuario usuario1){
		usuarioIC = usuario1;		
		initComponents();
		JOptionPane.showMessageDialog(null,"El a�o no coincide con el A�o fiscal","Error",JOptionPane.INFORMATION_MESSAGE);
		llenarAnios();
	}


	public InterfazMaximos(BeanUsuario usuario) {
		usuarioIC = usuario;		
		initComponents();
		JOptionPane.showMessageDialog(null, "En la siguiente ventana debe ingresar el a�o en el cual desea trabajar\n" +
				"Si el a�o ya exite y los limites que contiene son correctos solo ingrese el a�o y de clic en continuar\n" +
				"Si un a�o no contiene los limites correctos los puede modificar\n" +
				"En caso de que el a�o no se muestre en la tabla por favor ingreselo con sus respectivos limites antes de continuar\n" +
				"Para mayor informaci�n sobre los limites permitidos por cada a�o puede consultar en: http://www.sri.gob.ec/\n", "Seleccion del a�o",JOptionPane.INFORMATION_MESSAGE);
		llenarAnios();
		
	}


	private void initComponents() {

		txtLimConSalud = new javax.swing.JTextField();
		txtLimConAlimentacion = new javax.swing.JTextField();
		jSeparator2 = new javax.swing.JSeparator();
		txtLimConVivienda = new javax.swing.JTextField();
		jLabel7 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTableAnios = new javax.swing.JTable();
		jLabel3 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();
		txtLimConVestimenta = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		btmGuardar = new javax.swing.JButton();
		btmEliminar = new javax.swing.JButton();
		txtAnio = new javax.swing.JTextField();
		txtLimConEducacion = new javax.swing.JTextField();
		btmModificar = new javax.swing.JButton();
		jButton1 = new javax.swing.JButton();
		btnContinuar = new javax.swing.JButton();
		btnContinuar.setBackground(new java.awt.Color(204, 255, 204));

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		//setLocationRelativeTo(null);
		setTitle("A�o fiscal");
		txtLimConVivienda
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						txtLimConViviendaActionPerformed(evt);
					}
				});
		
		txtLimConVivienda.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtLimConVivienda.getText().length()== 9)		    	  
		    	     e.consume();
		    	}
		   }
		});
		txtLimConAlimentacion.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtLimConAlimentacion.getText().length()== 9)		    	  
		    	     e.consume();
		    	}
		   }
		});
		txtLimConSalud.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtLimConSalud.getText().length()== 9)		    	  
		    	     e.consume();
		    	}
		   }
		});		
		txtLimConVestimenta.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtLimConVestimenta.getText().length()== 9)		    	  
		    	     e.consume();
		    	}
		   }
		});	
		txtLimConEducacion.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtLimConEducacion.getText().length()== 9)		    	  
		    	     e.consume();
		    	}
		   }
		});			
		
		txtAnio.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtAnio.getText().length()== 4)		    	  
		    	     e.consume();
		    	}
		   }
		});	
		
		
		jLabel7.setText("                                       A�o");

		jLabel5.setText("                                       L�mite de vestimenta");

		jLabel4.setText("                                       L�mite de educacion");

		jTableAnios.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] { { null, null, null, null, null, null },
						{ null, null, null, null, null, null },
						{ null, null, null, null, null, null },
						{ null, null, null, null, null, null } },
				new String[] { "Anio", "Limite vivienda",
						"Limite alimentacion", "Limite salud",
						"Limite educacion", "Limite vestimenta" }));
		jScrollPane1.setViewportView(jTableAnios);
		jTableAnios.getSelectionModel().addListSelectionListener(new InterfazMaximos.RowListener());


		jLabel3.setText("                                       L�mite de salud");

		jLabel1.setText("                                       L�mite de vivienda");

		jLabel2.setText("                                       L�mite de alimentacion");

		btmGuardar.setText("Guardar");
		btmGuardar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btmGuardarActionPerformed(evt);
			}
		});

		btmEliminar.setText("Eliminar");
		btmEliminar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btmEliminarActionPerformed(evt);
			}
		});

		txtAnio.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				txtAnioActionPerformed(evt);
			}
		});

		btmModificar.setText("Modificar");
		btmModificar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btmActualizarActionPerformed(evt);
			}
		});

		jButton1.setText("Limpiar");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		btnContinuar.setText("Continuar");
		btnContinuar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnContinuarActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jSeparator2)
				.addGroup(
						layout.createSequentialGroup()
								.addComponent(jScrollPane1).addContainerGap())
				.addGroup(
						layout.createSequentialGroup()
								.addGap(19, 19, 19)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(
														layout.createSequentialGroup()
																.addGap(35, 35,
																		35)
																.addComponent(
																		btmGuardar)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																.addComponent(
																		btmModificar)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																.addComponent(
																		btmEliminar)
																.addGap(33, 33,
																		33)
																.addComponent(
																		jButton1)
																.addGap(33, 33,
																		33)
																.addComponent(
																		btnContinuar))
												.addGroup(
														layout.createSequentialGroup()
																.addGroup(
																		layout.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						jLabel7)
																				.addComponent(
																						jLabel1)
																				.addComponent(
																						jLabel2)
																				.addComponent(
																						jLabel3)
																				.addComponent(
																						jLabel4)
																				.addComponent(
																						jLabel5))
																.addGap(65, 65,
																		65)
																.addGroup(
																		layout.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.TRAILING,
																				false)																																				
																				.addComponent(
																						txtAnio,
																						javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						txtLimConVestimenta,
																						javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						txtLimConEducacion,
																						javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						txtLimConSalud,
																						javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						txtLimConAlimentacion,
																						javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						txtLimConVivienda,
																						javax.swing.GroupLayout.PREFERRED_SIZE,
																						94,
																						javax.swing.GroupLayout.PREFERRED_SIZE)
																
																)))
								.addContainerGap(
										javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)));
		layout.setVerticalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				
				.addGroup(
						layout.createSequentialGroup()
								.addContainerGap()
										
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
												.addGap(25, 25, 25)

												.addComponent(jLabel7)
												.addComponent(
														txtAnio,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel1)
												.addComponent(
														txtLimConVivienda,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(jLabel2)
												.addComponent(
														txtLimConAlimentacion,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel3)
												.addComponent(
														txtLimConSalud,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel4)
												.addComponent(
														txtLimConEducacion,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel5)
												.addComponent(
														txtLimConVestimenta,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(btmGuardar)
												.addComponent(btmEliminar)
												.addComponent(btmModificar)
												.addComponent(jButton1)
												.addComponent(btnContinuar))
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(jSeparator2,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										5,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addComponent(jScrollPane1,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										128,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap(
										javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)));

		pack();
	}


	private void txtLimConViviendaActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_txtLimConViviendaActionPerformed
	}

	private void btmGuardarActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btmGuardarActionPerformed
		ValidacionMaximos va = new ValidacionMaximos();
		OperacionesSQLite op = new OperacionesSQLite();
		boolean estadoDatos = false; 

		if (txtAnio.getText().equalsIgnoreCase("")
				|| txtLimConAlimentacion.getText().equalsIgnoreCase("")
				|| txtLimConEducacion.getText().equalsIgnoreCase("")
				|| txtLimConSalud.getText().equalsIgnoreCase("")
				|| txtLimConVestimenta.getText().equalsIgnoreCase("")
				|| txtLimConVivienda.getText().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null,
					"Deben estar llenos todos los campos");
		} else {

			estadoDatos = va.validacionLimites(txtAnio.getText(),
					txtLimConVivienda.getText(), txtLimConVestimenta.getText(),
					txtLimConEducacion.getText(), txtLimConSalud.getText(),
					txtLimConEducacion.getText());
			if (estadoDatos == true) {
				op.ingresarAnio(
						Integer.parseInt(txtAnio.getText()),
						Float.parseFloat(txtLimConAlimentacion.getText()),
						Float.parseFloat(txtLimConEducacion.getText()),
						Float.parseFloat(txtLimConSalud.getText()),
						Float.parseFloat(txtLimConVestimenta.getText()),
						Float.parseFloat(txtLimConVivienda.getText()));
				llenarAnios();

			} else {
				JOptionPane.showMessageDialog(null,
						"Verifique que los datos que intenta ingresar son correctos");
			}

		}
	}

	private void btmEliminarActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btmModificarActionPerformed
		OperacionesSQLite op = new OperacionesSQLite();
		op.eliminarAnio(Integer.parseInt(txtAnio.getText()));
		llenarAnios();
	}

	private void txtAnioActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_txtAnioActionPerformed
	}


	
	
	private void btmActualizarActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btmActualizarActionPerformed
	ValidacionMaximos va = new ValidacionMaximos();
		OperacionesSQLite op = new OperacionesSQLite();
		boolean estadoDatos = false;

		if (txtAnio.getText().equalsIgnoreCase("")
				|| txtLimConAlimentacion.getText().equalsIgnoreCase("")
				|| txtLimConEducacion.getText().equalsIgnoreCase("")
				|| txtLimConSalud.getText().equalsIgnoreCase("")
				|| txtLimConVestimenta.getText().equalsIgnoreCase("")
				|| txtLimConVivienda.getText().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null,
					"Deben estar llenos todos los campos");
		} else {

			estadoDatos = va.validacionLimites(txtAnio.getText(),
					txtLimConVivienda.getText(), txtLimConVestimenta.getText(),
					txtLimConEducacion.getText(), txtLimConSalud.getText(),
					txtLimConEducacion.getText());
			if (estadoDatos == true) {
				op.modificarAnio(Integer.parseInt(txtAnio.getText()),
						Float.parseFloat(txtLimConVivienda.getText()),
						Float.parseFloat(txtLimConAlimentacion.getText()),
						Float.parseFloat(txtLimConSalud.getText()),
						Float.parseFloat(txtLimConEducacion.getText()),
						Float.parseFloat(txtLimConVestimenta.getText()));
				llenarAnios();

			} else {
				JOptionPane.showMessageDialog(null,
						"Verifique que los datos que intenta ingresar son correctos");
			}

		}

	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed
		txtAnio.setText("");
		txtLimConAlimentacion.setText("");
		txtLimConEducacion.setText("");
		txtLimConSalud.setText("");
		txtLimConVestimenta.setText("");
		txtLimConVivienda.setText("");

	}
	private int var3; 

	public void setVar1(String var1){ 
	this.var3=var3; 
	} 

	public int getVar1(){ 
	return this.var3; 
	} 

	public void modificarValorVar1(int var4){ 
	this.var3 = var4; 
	}
	
	private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed
		if(txtAnio.getText().length()==0)
		{
			JOptionPane.showMessageDialog(null,"Ingrese el a�o con el que va a trabajar esta sesi�n antes de continuar");	
		}
		else
		{
			OperacionesSQLite op = new OperacionesSQLite();
			boolean annio = op.consultarAnio(Integer.parseInt(txtAnio.getText()));
			if (annio==true)
			{
				MenuPrincipal mp = new MenuPrincipal(usuarioIC, Integer.parseInt(txtAnio.getText()));
				mp.setVisible(true);
				dispose();
			}
			
		}
		int var4=Integer.parseInt(txtAnio.getText());
		
		
	}

 	class RowListener implements ListSelectionListener {
	public void valueChanged(ListSelectionEvent event) {
	
		try{

			int renglon = jTableAnios.getSelectedRow();
			jTableAnios.isCellEditable(renglon, 0);
			jTableAnios.isCellEditable(renglon, 1);
			jTableAnios.isCellEditable(renglon, 2);
			jTableAnios.isCellEditable(renglon, 3);
			jTableAnios.isCellEditable(renglon, 4);
			jTableAnios.isCellEditable(renglon, 5);

			txtAnio.setText(jTableAnios.getValueAt(renglon, 0).toString());
			txtLimConVivienda.setText(jTableAnios.getValueAt(renglon, 1).toString());
			txtLimConAlimentacion.setText(jTableAnios.getValueAt(renglon, 2).toString());
			txtLimConEducacion.setText(jTableAnios.getValueAt(renglon,4).toString());
			txtLimConSalud.setText(jTableAnios.getValueAt(renglon, 3).toString());
			txtLimConVestimenta.setText(jTableAnios.getValueAt(renglon, 5).toString());


		}
		catch(Exception e)
		{
			System.out.println("");
		}
		
	}
}


}
