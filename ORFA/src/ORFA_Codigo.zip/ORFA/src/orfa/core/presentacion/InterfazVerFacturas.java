package orfa.core.presentacion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import orfa.core.datos.Exporter;
import orfa.core.datos.OperacionesSQLite;
import orfa.utils.beans.BeanUsuario;

/**
 *
 * @author JAIRO
 */

public class InterfazVerFacturas extends javax.swing.JFrame {
	private static BeanUsuario usuarioIF;
    /**
     * Creates new form VerFacturas
     */
    public InterfazVerFacturas(BeanUsuario usuario) {
    	usuarioIF = usuario;
        initComponents();
        Datos(0);
    }


    public void Datos(int anio)
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaVerFacturas.setModel(new DefaultTableModel());
	    if(anio!=0)
	    {
	    	model = op.listaFacturas(usuarioIF.getIdUsuario(), anio);
	    }
	    else
	    {
	    	model = op.listaTodasFacturas(usuarioIF.getIdUsuario());
	    }
	    tablaVerFacturas.setModel(model);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tablaVerFacturas = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jTextField1.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (jTextField1.getText().length()== 4  && caracter != '\b' /*corresponde a BACK_SPACE*/)		    	  
		    	     e.consume();
		    	}
		   }
		});	
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        //setLocationRelativeTo(null);
        setTitle("Reportes");
        tablaVerFacturas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tablaVerFacturas);

        jButton1.setText("Cancelar");

        jLabel1.setText("A�o Factura:");

        jButton2.setText("Consultar");
        jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(jTextField1.getText().length()==0)
				{
					Datos(0);
				}
				else
				{
					int a=Integer.parseInt(jTextField1.getText());
					if (a==0)
					{
						Datos(0);
					}
					else
					{
						Datos(a);
					}
				}
				
			}
		});

        jButton3.setText("Exportar a Excel");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
		         if (tablaVerFacturas.getRowCount() > 0) {
		             JFileChooser chooser = new JFileChooser();
		             FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de excel", "xls");
		             chooser.setFileFilter(filter);
		             chooser.setDialogTitle("Guardar archivo");
		             chooser.setAcceptAllFileFilterUsed(false);
		             if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
		                 List<JTable> tb = new ArrayList<JTable>();
		                 List<String> nom = new ArrayList<String>();
		                 tb.add(tablaVerFacturas);
		                 nom.add("Personas");
		                 String file = chooser.getSelectedFile().toString().concat(".xls");
		                 try {
		                     Exporter e = new Exporter(new File(file), tb, nom);
		                     if (e.export()) {
		                         JOptionPane.showMessageDialog(null, "Los datos fueron exportados a excel en el directorio seleccionado", "Mensaje de Informacion", JOptionPane.INFORMATION_MESSAGE);
		                     }
		                 } catch (Exception e) {
		                     JOptionPane.showMessageDialog(null, "Hubo un error " + e.getMessage(), " Error", JOptionPane.ERROR_MESSAGE);
		                 }
		             }
		         }else{
		             JOptionPane.showMessageDialog(null, "No hay datos para exportar","Mensaje de error",JOptionPane.ERROR_MESSAGE);
		         }
		         
            }
          });

        jButton4.setText("Ver L�mites del A�o");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	OperacionesSQLite op = new OperacionesSQLite();
            	if(jTextField1.getText().length()!=0)
            	{
	            	int a=Integer.parseInt(jTextField1.getText());
					boolean comprobador=op.consultarAnio(a);
					if(comprobador==true)
					{
						int anio=Integer.parseInt(jTextField1.getText());                
						//deducibles
						float vi=op.totalVivienda(usuarioIF.getIdUsuario(),anio);
						float al=op.totalAlimentacion(usuarioIF.getIdUsuario(),anio);
		                float sa=op.totalSalud(usuarioIF.getIdUsuario(),anio);
		                float ed=op.totalEducacion(usuarioIF.getIdUsuario(),anio);
		                float ve=op.totalVestimenta(usuarioIF.getIdUsuario(),anio);
		                float td=vi+al+sa+ed+ve;
		                //no deducibles
		                float ot=op.totalOtros(usuarioIF.getIdUsuario(),anio);
		                float iv=op.totalIVA(usuarioIF.getIdUsuario(),anio);
		                
		                //total factura
		                float tf=op.totalFacturas(usuarioIF.getIdUsuario(),anio);
		                         
		                // limites por a�o
		                float maxViv=op.maximoViviendaAnio(anio);
		                float maxAlim=op.maximoAlimentacionAnio(anio);
		                float maxSal=op.maximoSaludAnio(anio);
		                float maxEdu=op.maximoEducacionAnio(anio);
		                float maxVes=op.maximoVestimentaAnio(anio);
		                
		                //diferencia hasta llegar al limite
		                float difViv=maxViv-vi;
		                float difAlim=maxAlim-al;
		                float difSal=maxSal-sa;
		                float difEdu=maxEdu-ed;
		                float difVes=maxVes-ve;
		                float difDed=maxSal-(vi+al+sa+ed+ve);
		                
		                
		               /* String supViv="no";
		                String supAlim="no";
		                String supSal="no";
		                String supEdu="no";
		                String supVes="no";
		                String supDed="no";
		                
		                if(vi>maxViv)
		                {
		                	supViv="si";
		                }
		                if(al>maxAlim)
		                {
		                	supAlim="si";
		                }
		                if(sa>maxSal)
		                {
		                	supSal="si";
		                }
		                if(ed>maxEdu)
		                {
		                	supEdu="si";
		                }
		                if(ve>maxVes)
		                {
		                	supVes="si";
		                }
		                if(td>maxSal)
		                {
		                	supDed="si";
		                }
		                */
		                Object[][] rows = {
		                	    {"Vivienda",vi,maxViv,difViv},
		                	    {"Alimentacion",al,maxAlim,difAlim},
		                	    {"Salud",sa,maxSal,difSal},
		                	    {"Educacion",ed,maxEdu,difEdu},
		                	    {"Vestimenta",ve,maxVes,difVes},
		                	    {"TOTAL DEDUCIBLES",td,maxSal,difDed}
		                	};
		                	Object[] cols = {
		                	    "Categoria","Total en este a�o","Limite","Limite - Gastado"
		                	};
		            	    tablaVerFacturas.setModel(new DefaultTableModel());
		            	    DefaultTableModel modelo = new DefaultTableModel(rows, cols);
		            	    tablaVerFacturas.setModel(modelo);
		            }
            	}
            	else
            	{
            		JOptionPane.showMessageDialog(null,"Ingrese un a�o para poder ver sus limites" ,"Limites para el a�o X",JOptionPane.INFORMATION_MESSAGE);
            	}
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(369, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton3)
                                .addGap(18, 18, 18)
                                .addComponent(jButton4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                //.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE))
                        .addGap(43, 43, 43))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    //.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addGap(40, 40, 40))
        );

        pack();
    }// </editor-fold>                        

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazVerFacturas(usuarioIF).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTable tablaVerFacturas;
    // End of variables declaration                   
}
