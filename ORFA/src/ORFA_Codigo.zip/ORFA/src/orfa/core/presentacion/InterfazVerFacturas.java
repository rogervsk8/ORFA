package orfa.core.presentacion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import orfa.core.datos.Conexion;
import orfa.core.datos.Exporter;
import orfa.core.datos.OperacionesSQLite;
import orfa.utils.beans.BeanUsuario;

import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JComboBox;

import orfa.core.presentacion.InterfazFactura;
import orfa.core.datos.Conexion;
import orfa.core.datos.DatosFactura;
import orfa.core.datos.Exporter;
import orfa.core.datos.OperacionesSQLite;
import orfa.utils.beans.*;

/**
 *
 * @author JAIRO
 */
public class InterfazVerFacturas extends javax.swing.JFrame {
	private static BeanUsuario usuarioIF;
	private Object labelInfo;
    //private BeanUsuario usuarioIF;
    private int anioDeTrabajo;
    /**
     * Creates new form VerFacturas
     */
    public InterfazVerFacturas(BeanUsuario usuario) {
    	usuarioIF = usuario;
        initComponents();
        Datos(0);
        llenar();
       
    }
    
    
    public void Acumulado()
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaVerFacturas.setModel(new DefaultTableModel());
    	model = op.listaAcumuladoXproveedor(usuarioIF.getIdUsuario());
	    tablaVerFacturas.setModel(model);
    }
    
    public void AcumuladoXproveedor(String proveedor)
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaVerFacturas.setModel(new DefaultTableModel());
    	model = op.listaAcumuladoXproveedorSeleccionado(usuarioIF.getIdUsuario(), proveedor);
	    tablaVerFacturas.setModel(model);
    }
    

    public void Datos(int anio)
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaVerFacturas.setModel(new DefaultTableModel());
	    if(anio!=0)
	    {
	    	model = op.listaFacturas(usuarioIF.getIdUsuario(), anio);
	    }
	    else
	    {
	    	model = op.listaTodasFacturas(usuarioIF.getIdUsuario());
	    }
	    tablaVerFacturas.setModel(model);
    }
    
    public void DatosMesYanio(int anio, String mes)
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaVerFacturas.setModel(new DefaultTableModel());
    	model = op.listaTodasFacturasXmesYanio(usuarioIF.getIdUsuario(),mes,anio);
	    tablaVerFacturas.setModel(model);
    }
    
    public void DatosMesYanioYproveedor(int anio, String mes, String proveedor)
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaVerFacturas.setModel(new DefaultTableModel());
    	model = op.listaTodasFacturasXmesYanioYproveedor(usuarioIF.getIdUsuario(),mes,anio,proveedor);
	    tablaVerFacturas.setModel(model);
    }

    public void DatosAnioYproveedor(int anio, String proveedor)
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaVerFacturas.setModel(new DefaultTableModel());
    	model = op.listaTodasFacturasXanioYproveedor(usuarioIF.getIdUsuario(),anio,proveedor);
	    tablaVerFacturas.setModel(model);
    }    
    
    
    Connection cn;
    ResultSet rs;
  public void llenar()
  {
 	 Conexion conexion= new Conexion();
 	 try{
          cn = conexion.enlace(cn);
         
         java.sql.Statement s=cn.createStatement();
       String query = "select * from proveedor";
 rs = s.executeQuery(query);
 comboBox.removeAllItems();
 comboBox.addItem("Todos");
  while(rs.next())
         {
            comboBox.addItem(rs.getString("nombre_proveedor"));
         }
     s.close();
     cn.close();
     }
      catch(Exception ex)
     {
        JOptionPane.showMessageDialog(null, ex);
     }
  }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tablaVerFacturas = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        comboBox_1= new javax.swing.JComboBox();
        comboBox = new javax.swing.JComboBox();
        jTextField1.addKeyListener(new KeyAdapter()

		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (jTextField1.getText().length()== 4  && caracter != '\b' /*corresponde a BACK_SPACE*/)		    	  
		    	     e.consume();
		    	}
		   }
		});	
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        //setLocationRelativeTo(null);
        setTitle("Reportes");
        tablaVerFacturas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tablaVerFacturas);

        jButton1.setText("Cancelar");

        jLabel1.setText("A�o Factura:");

        jButton2.setText("Consultar");
        jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(jTextField1.getText().length()==0)
				{
					JOptionPane.showMessageDialog(null, "Ingrese un a�o para realizar la consulta","Ingrese un a�o",JOptionPane.ERROR_MESSAGE);
				}
				else
				{
					int a=Integer.parseInt(jTextField1.getText());
					String mes= (String) comboBox_1.getSelectedItem();
					String proveedor= (String) comboBox.getSelectedItem();
					if(mes =="Todos" && proveedor=="Todos")
					{
						Datos(a);
						
					}
					if(mes!="Todos" && proveedor=="Todos")
					{
						DatosMesYanio(a, mes);
					}
					if(mes=="Todos" && proveedor!="Todos")
					{
						DatosAnioYproveedor(a, proveedor);
					}
					if(mes!="Todos" && proveedor!="Todos")
					{
						DatosMesYanioYproveedor(a, mes, proveedor);
					}

				}
				
			}
		});

        jButton3.setText("Exportar a Excel");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
		         if (tablaVerFacturas.getRowCount() > 0) {
		             JFileChooser chooser = new JFileChooser();
		             FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de excel", "xls");
		             chooser.setFileFilter(filter);
		             chooser.setDialogTitle("Guardar archivo");
		             chooser.setAcceptAllFileFilterUsed(false);
		             if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
		                 List<JTable> tb = new ArrayList<JTable>();
		                 List<String> nom = new ArrayList<String>();
		                 tb.add(tablaVerFacturas);
		                 nom.add("Personas");
		                 String file = chooser.getSelectedFile().toString().concat(".xls");
		                 try {
		                     Exporter e = new Exporter(new File(file), tb, nom);
		                     if (e.export()) {
		                         JOptionPane.showMessageDialog(null, "Los datos fueron exportados a excel en el directorio seleccionado", "Mensaje de Informacion", JOptionPane.INFORMATION_MESSAGE);
		                     }
		                 } catch (Exception e) {
		                     JOptionPane.showMessageDialog(null, "Hubo un error " + e.getMessage(), " Error", JOptionPane.ERROR_MESSAGE);
		                 }
		             }
		         }else{
		             JOptionPane.showMessageDialog(null, "No hay datos para exportar","Mensaje de error",JOptionPane.ERROR_MESSAGE);
		         }
		         
            }
          });

        jButton4.setText("Ver L�mites del A�o");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	OperacionesSQLite op = new OperacionesSQLite();
            	if(jTextField1.getText().length()!=0)
            	{
	            	int a=Integer.parseInt(jTextField1.getText());
					boolean comprobador=op.consultarAnio(a);
					if(comprobador==true)
					{
						int anio=Integer.parseInt(jTextField1.getText());                
						//deducibles
						float vi=op.totalVivienda(usuarioIF.getIdUsuario(),anio);
						float al=op.totalAlimentacion(usuarioIF.getIdUsuario(),anio);
		                float sa=op.totalSalud(usuarioIF.getIdUsuario(),anio);
		                float ed=op.totalEducacion(usuarioIF.getIdUsuario(),anio);
		                float ve=op.totalVestimenta(usuarioIF.getIdUsuario(),anio);
		                float td=vi+al+sa+ed+ve;
		                //no deducibles
		                float ot=op.totalOtros(usuarioIF.getIdUsuario(),anio);
		                float iv=op.totalIVA(usuarioIF.getIdUsuario(),anio);
		                
		                //total factura
		                float tf=op.totalFacturas(usuarioIF.getIdUsuario(),anio);
		                         
		                // limites por a�o
		                float maxViv=op.maximoViviendaAnio(anio);
		                float maxAlim=op.maximoAlimentacionAnio(anio);
		                float maxSal=op.maximoSaludAnio(anio);
		                float maxEdu=op.maximoEducacionAnio(anio);
		                float maxVes=op.maximoVestimentaAnio(anio);
		                
		                //diferencia hasta llegar al limite
		                float difViv=maxViv-vi;
		                float difAlim=maxAlim-al;
		                float difSal=maxSal-sa;
		                float difEdu=maxEdu-ed;
		                float difVes=maxVes-ve;
		                float difDed=maxSal-(vi+al+sa+ed+ve);
		                

		                Object[][] rows = {
		                	    {"Vivienda",vi,maxViv,difViv},
		                	    {"Alimentacion",al,maxAlim,difAlim},
		                	    {"Salud",sa,maxSal,difSal},
		                	    {"Educacion",ed,maxEdu,difEdu},
		                	    {"Vestimenta",ve,maxVes,difVes},
		                	    {"TOTAL DEDUCIBLES",td,maxSal,difDed}
		                	};
		                	Object[] cols = {
		                	    "Categoria","Total en este a�o","Limite","Limite - Gastado"
		                	};
		            	    tablaVerFacturas.setModel(new DefaultTableModel());
		            	    DefaultTableModel modelo = new DefaultTableModel(rows, cols);
		            	    tablaVerFacturas.setModel(modelo);
		            }
            	}
            	else
            	{
            		JOptionPane.showMessageDialog(null,"Ingrese un a�o para poder ver sus limites" ,"Limites para el a�o X",JOptionPane.INFORMATION_MESSAGE);
            	}
            }
        });
        
        JLabel lblMes = new JLabel("Mes");
        
        JLabel lblProveedor = new JLabel("Proveedor");
        
        //JComboBox comboBox = new JComboBox();
        
        
    	
                		
	
       // JComboBox comboBox_1 = new JComboBox();
        comboBox_1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Todos", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }));
        
        comboBox_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	//actionPerformed(evt);
            }
        });
        

        
        JButton btnAyuda = new JButton("Ayuda");
        btnAyuda.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		JOptionPane.showMessageDialog(null, "En la presente ventana puede realizar distintas b�squedas de diferentes formas, todas las formas posibles son:\n"
        				+ "  * Para el bot�n Consultar:\n"
        				+ "    - B�squeda por a�o (Ingrese un a�o y deje el campo Mes y Proveedor con la opci�n Todos)\n"
        				+ "    - B�squea por a�o y mes (Ingrese un a�o y seleccione de la lista un mes, deje en Proveedor la opci�n Todos)\n"
        				+ "    - B�squeda por a�o y proveedor (Ingrese un a�o y seleccione un proveedor, deje en Mes la opci�n Todos)\n"
        				+ "    - B�squeda por a�o, mes y proveedor (Ingrese un a�o y seleccione un Mes y Proveedor)\n"
        				+ "\n"
        				+ "  * Para el bot�n Desplegar todo\n"
        				+ "    - No se necesita llenar ni un campo, nos muestra todas las facturas del usuario\n"
        				+ "\n"
        				+ " *  Para el  bot�n Ver L�mites del A�o\n"
        				+ "   -  Solamente ingrese un a�o y se mostrar� los gastos, l�mites y la diferencia de ellos seg�n el a�o ingresado\n"
        				+ "\n"
        				+ "  * Para el bot�n Consultar acumulado por proveedor\n"
        				+ "    - Ingrese un proveedor para consultar el total acumulado por a�o de dicho proveedor\n"
        				+ "    - Deje maracada la opci�n Todos en proveedor para mostrar el total acumulado de todos los proveedores por cada a�o\n", "AYUDA",JOptionPane.INFORMATION_MESSAGE);  
        	}
        });

        JButton btnConsultarAcumuladoPor = new JButton("Consultar acumulado por proveedor");
        btnConsultarAcumuladoPor.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		OperacionesSQLite op = new OperacionesSQLite();
				String proveedor= (String) comboBox.getSelectedItem();
        		if (proveedor=="Todos")
        		{
        			Acumulado();
        		}
        		else
        		{
        			AcumuladoXproveedor(proveedor);
        		}
        		
        	}
        });
        
        btnNewButton = new JButton("Desplegar todo");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		Datos(0);
        	}
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(34)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton)
        					.addGap(761))
        				.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        					.addGroup(layout.createSequentialGroup()
        						.addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 916, Short.MAX_VALUE)
        						.addGap(43))
        					.addGroup(layout.createSequentialGroup()
        						.addComponent(jButton3)
        						.addGap(18)
        						.addComponent(jButton4)
        						.addGap(33)
        						.addComponent(btnConsultarAcumuladoPor)
        						.addContainerGap(469, Short.MAX_VALUE))
        					.addGroup(layout.createSequentialGroup()
        						.addGroup(layout.createParallelGroup(Alignment.LEADING)
        							.addComponent(jLabel1)
        							.addComponent(lblMes)
        							.addComponent(lblProveedor))
        						.addPreferredGap(ComponentPlacement.RELATED)
        						.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        							.addComponent(jTextField1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
        							.addComponent(comboBox_1, 0, 129, Short.MAX_VALUE)
        							.addComponent(comboBox, 0, 129, Short.MAX_VALUE))
        						.addGap(680)
        						.addComponent(btnAyuda)
        						.addGap(20)))))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(22)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel1)
        				.addComponent(btnAyuda))
        			.addGap(28)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(lblMes)
        				.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addGap(31)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(lblProveedor)
        				.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addGap(18)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton))
        			.addPreferredGap(ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
        			.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 285, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jButton3)
        				.addComponent(jButton4)
        				.addComponent(btnConsultarAcumuladoPor))
        			.addGap(40))
        );
        getContentPane().setLayout(layout);

        pack();
    }// </editor-fold>                        

    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazVerFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               // new InterfazVerFacturas(usuarioIF).setVisible(true);
            }
        });
        
    }
    void init(){
		while (comboBox_1.getModel().getSize() > 0) comboBox_1.removeItemAt(0);
		comboBox_1.addItem("espanya");
		comboBox_1.addItem("italia");
	}


    // Variables declaration - do not modify     
    private javax.swing.JComboBox comboBox;
    private javax.swing.JComboBox comboBox_1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTable tablaVerFacturas;
    private JButton btnNewButton;
}
