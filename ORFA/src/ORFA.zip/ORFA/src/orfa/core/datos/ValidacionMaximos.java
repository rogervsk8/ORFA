package orfa.core.datos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Calendar;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import orfa.utils.beans.BeanUsuario;
import orfa.core.datos.ValidacionMaximos;


public class ValidacionMaximos {
	int anio;
	float maxVivienda;
	float maxVestimenta;
	float maxAlimentacion;
	float maxSalud;
	float maximoEducacion;

	public boolean validacionLimites(String ano, String vivienda, String vestimenta, String educacion, String salud, String alimentacion) {
		boolean Validacion = false;
		String error = "";

		try {
			Calendar fecha = Calendar.getInstance();
			anio = Integer.parseInt(ano);
			int anioPC = fecha.get(Calendar.YEAR);
			if(anio<2000 || anio>anioPC)
			{
				error = "SI";
				JOptionPane.showMessageDialog(null, "EL A�O QUE INTENTA INGRESAR ES INCORRECTO", "A�O", JOptionPane.ERROR_MESSAGE);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR AL INGRESAR EL A�O", "A�O", JOptionPane.ERROR_MESSAGE);
			error = "SI";
		}
		try {

			maxAlimentacion = Float.parseFloat(alimentacion);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR AL INGRESAR EL MAXIMO DE ALIMENTACION", "MAXIMO ALIMENTACION", JOptionPane.ERROR_MESSAGE);
			error = "SI";
		}
		try {

			maximoEducacion = Float.parseFloat(educacion);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR AL INGRESAR EL MAXIMO DE EDUCACION", "MAXIMO EDUCACION", JOptionPane.ERROR_MESSAGE);
			error = "SI";
		}
		try {

			maxSalud = Float.parseFloat(salud);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR AL INGRESAR EL MAXIMO DE SALUD", "MAXIMO SALUD", JOptionPane.ERROR_MESSAGE);
			error = "SI";
		}
		try {

			maxVestimenta = Float.parseFloat(vestimenta);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR AL INGRESAR EL MAXIMO DE VESTIMENTA", "MAXIMO VESTIMENTA", JOptionPane.ERROR_MESSAGE);
			error = "SI";
		}
		try {

			maxVivienda = Float.parseFloat(vivienda);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR AL INGRESAR EL MAXIMO DE VIVIENDA", "MAXIMO VIVIENDA", JOptionPane.ERROR_MESSAGE);
			error = "SI";
		}

		if (error == "SI") {
			Validacion = false;
		}
		else {
			Validacion = true;
		}
		return Validacion;
	}
}
