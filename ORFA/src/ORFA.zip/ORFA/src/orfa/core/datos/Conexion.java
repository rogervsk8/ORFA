/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orfa.core.datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

import orfa.utils.beans.BeanUsuario;

/**
 * 
 * @author OMAR S
 */
public class Conexion {
	static Connection cn;

	public Conexion() {
	}

	public static Connection enlace(Connection cn) throws SQLException {
		// ruta de la base de datos la cual crearemos

		// String ruta =
		// "/home/efesan/Documentos/EPN/FIS/Semestres/2015A/AppAmbLibres/Proyecto/EspacioTrabajoOrfa/ORFA/src/BD/orfa_database.db";
		try {
			Class.forName("org.sqlite.JDBC");
			cn = DriverManager.getConnection("jdbc:sqlite:orfa_database.db");
			
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, e);
		}
		return cn;
	}

	public String consultarIDUsuario() {
		ResultSet rs = null;
		String idUsuario = null;
		String sql = "select max(id_usuario)+1 as idUsuario from usuario;";
		try {
			Statement sentencia = enlace(cn).createStatement();
			rs = sentencia.executeQuery(sql);
			idUsuario = rs.getString("idUsuario");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					("No se pudo obtener id de usuario " + e));
		}
		return idUsuario;
	}

	public boolean validarUsuario(String usuario, String contrasena) {
		boolean acceso = false;
		ResultSet rs = null;

		String sql = "select id_usuario from usuario where nick_usuario='"
				+ usuario + "' and password_usuario='" + contrasena + "';";
		try {
			System.out.println("entre al try");
			Statement sentencia = enlace(cn).createStatement();
			rs = sentencia.executeQuery(sql);
			while(rs.next())
			{
			if (!rs.getString("id_usuario").equals(""))
				acceso = true;
			else
				acceso = false;
			}
		} catch (Exception e) {
			System.out.println("entre al catch");
			acceso = false;
		}
		return acceso;
	}
	public boolean recuperar (String nick, String respuesta){
		boolean acceso = false;
		ResultSet rs = null;

		String sql = "select id_usuario from usuario where nick_usuario='"
				+ nick + "' and respuesta_usuario='" + respuesta + "';";
		try {
			System.out.println("entre al try454");
			Statement sentencia = enlace(cn).createStatement();
			rs = sentencia.executeQuery(sql);
			while(rs.next())
			{
				System.out.println("entre al while");
			if (!rs.getString("id_usuario").equals("")){
				acceso = true; 
				System.out.println("entre al if del rs");
			}
				
			else{
				acceso = false;
				System.out.println("entre al else");
			}
			}
		} catch (Exception e) {
			System.out.println("entre al catch"+e);
			acceso = false;
		}
		return acceso;
	}

	public static BeanUsuario usuarioDevuelto(String usuario, String contrasena) {
		//boolean acceso = false;
		ResultSet rs = null;
		BeanUsuario usuarioRetorno = new BeanUsuario();

		String sql = "select * from usuario where nick_usuario='" + usuario
				+ "' and password_usuario='" + contrasena + "';";
		try {
			Statement sentencia = enlace(cn).createStatement();
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				usuarioRetorno.setIdUsuario(rs.getInt("id_usuario"));
				usuarioRetorno.setCedulaUsuario(rs.getString("ruc_usuario"));
				usuarioRetorno.setEmailUsuario(rs.getString("correo_usuario"));
				usuarioRetorno.setNickUsuario(rs.getString("nick_usuario"));
				usuarioRetorno.setSalarioAnual(rs.getFloat("salario_usuario"));
				usuarioRetorno.setNombreUsuario(rs.getString("nombre_usuario"));
				usuarioRetorno.setApellidoUsuario(rs.getString("apellido_usuario"));
				
				
			}
		} catch (Exception e) {
			System.out.println("No se pudo establecer la conexi�n con el subsistema de BD.");
		}
		return usuarioRetorno;
	}
	public static BeanUsuario usuarioDevuelto2(String usuario, String respuesta) {
		//boolean acceso = false;
		ResultSet rs = null;
		BeanUsuario usuarioRetorno = new BeanUsuario();

		String sql = "select * from usuario where nick_usuario='" + usuario
				+ "' and respuesta_usuario='" + respuesta + "';";
		try {
			Statement sentencia = enlace(cn).createStatement();
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				usuarioRetorno.setIdUsuario(rs.getInt("id_usuario"));
				usuarioRetorno.setCedulaUsuario(rs.getString("ruc_usuario"));
				usuarioRetorno.setEmailUsuario(rs.getString("correo_usuario"));
				usuarioRetorno.setNickUsuario(rs.getString("nick_usuario"));
				usuarioRetorno.setSalarioAnual(rs.getFloat("salario_usuario"));
				usuarioRetorno.setNombreUsuario(rs.getString("nombre_usuario"));
				usuarioRetorno.setApellidoUsuario(rs.getString("apellido_usuario"));
				
				
			}
		} catch (Exception e) {
			System.out.println("No se pudo establecer la conexi�n con el subsistema de BD.");
		}
		return usuarioRetorno;
	}
}