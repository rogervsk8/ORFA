package orfa.core.presentacion;

import javax.swing.JOptionPane;

import orfa.core.datos.BaseDatos;

public class InicioOrfa {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			new BaseDatos().crearBD();
			new InterfazLogin().setVisible(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Ha fallado el lanzamiento",
					"Info", JOptionPane.PLAIN_MESSAGE);
		}

	}

}