/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orfa.core.presentacion;

import orfa.utils.beans.BeanUsuario;
import orfa.core.presentacion.InterfazFactura;


public class MenuPrincipal extends javax.swing.JFrame {

	BeanUsuario usuarioMP = null;// new BeanUsuario();
	int annio=0;

	public MenuPrincipal(BeanUsuario usuario, int anyo) {
		usuarioMP = usuario;
		annio=anyo;
		initComponents();
	}


	private void initComponents() {

		setTitle("Bienvenid@  " + usuarioMP.getNombreUsuario().toUpperCase());

		jMenuBar1 = new javax.swing.JMenuBar();
		menuFactura = new javax.swing.JMenu();
		jMenuItem1 = new javax.swing.JMenuItem();
		menuUsuario = new javax.swing.JMenu();
		jMenuItem2 = new javax.swing.JMenuItem();
		menuProveedor = new javax.swing.JMenu();
		jMenuItem3 = new javax.swing.JMenuItem();
		jMenuItem4 = new javax.swing.JMenuItem();
		jMenuItem5 = new javax.swing.JMenuItem();
		jMenuItem6 = new javax.swing.JMenuItem();
		menuReportes = new javax.swing.JMenu();
		mItemVisualizador = new javax.swing.JMenuItem();
		menuSistema = new javax.swing.JMenu();
		mItemConfiguracion = new javax.swing.JMenuItem();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		//setLocationRelativeTo(null);
		menuFactura.setText("Factura");

		jMenuItem1.setText("Gesti�n de facturas");
		jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem1ActionPerformed(evt);
			}
		});
		menuFactura.add(jMenuItem1);
		
		jMenuItem6.setText("Cambiar a�o fiscal");
		jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem6ActionPerformed(evt);
			}
		});
		menuFactura.add(jMenuItem6);


		jMenuBar1.add(menuFactura);

		menuUsuario.setText("Usuario");

		jMenuItem2.setText("Modificar Usuario");
		jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem2ActionPerformed(evt);
			}
		});
		menuUsuario.add(jMenuItem2);
	
		jMenuItem5.setText("Cerrar Sesion");
		jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem22ActionPerformed(evt);
			}
		});
		menuUsuario.add(jMenuItem5);


		

		menuProveedor.setText("Proveedor");

		jMenuItem3.setText("Registrar proveedor");
		jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem3ActionPerformed(evt);
			}
		});
		menuProveedor.add(jMenuItem3);

		jMenuBar1.add(menuProveedor);

		menuReportes.setText("Reportes");

		jMenuItem4.setText("Reportes");
		jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem4ActionPerformed(evt);
			}
		});
		menuReportes.add(jMenuItem4);

		jMenuBar1.add(menuReportes);
		jMenuBar1.add(menuUsuario);
		setJMenuBar(jMenuBar1);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 400,
				Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 279,
				Short.MAX_VALUE));

		pack();
	}

	private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem2ActionPerformed
		InterfazGestionUsuarios jUsuario = new InterfazGestionUsuarios(
				usuarioMP, "Actualizar usuario");
		jUsuario.setVisible(true);
	}

	private void jMenuItem22ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem2ActionPerformed
		this.setVisible(false);
		InterfazLogin log = new InterfazLogin();
		log.setVisible(true);
	}
	
	private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem3ActionPerformed
		InterfazProveedor.main(null);
	}
	
	private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem3ActionPerformed
		InterfazVerFacturas fac = new InterfazVerFacturas(usuarioMP);
		fac.setVisible(true);	
	}

	private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem5ActionPerformed
		this.setVisible(false);
		InterfazMaximos max = new InterfazMaximos(usuarioMP);
		max.setVisible(true);
		
	}

	private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem1ActionPerformed
		InterfazFactura jFactura = new InterfazFactura(usuarioMP, annio);
		jFactura.setVisible(true);
		
	}

	private void mItemConfiguracionrActionPerformed(
			java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem1ActionPerformed
		InterfazMaximos configuracion = new InterfazMaximos(null);
		configuracion.setVisible(true);
	}


	private javax.swing.JMenuBar jMenuBar1;
	private javax.swing.JMenuItem mItemVisualizador;
	private javax.swing.JMenuItem mItemConfiguracion;
	private javax.swing.JMenuItem jMenuItem1;
	private javax.swing.JMenuItem jMenuItem2;
	private javax.swing.JMenuItem jMenuItem22;
	private javax.swing.JMenuItem jMenuItem3;
	private javax.swing.JMenuItem jMenuItem44;
	private javax.swing.JMenuItem jMenuItem4;
	private javax.swing.JMenuItem jMenuItem5;
	private javax.swing.JMenuItem jMenuItem6;
	private javax.swing.JMenu menuFactura;
	private javax.swing.JMenu menuProveedor;
	private javax.swing.JMenu menuUsuario;
	private javax.swing.JMenu menuReportes;
	private javax.swing.JMenu menuSistema;
	// End of variables declaration//GEN-END:variables
}