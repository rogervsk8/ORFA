/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orfa.core.presentacion;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.sql.Connection;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

import orfa.core.datos.Conexion;
import orfa.core.datos.DatosFactura;
import orfa.core.datos.Exporter;
import orfa.core.datos.OperacionesSQLite;
import orfa.utils.beans.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 




import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import orfa.core.presentacion.DatePicker;

import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import orfa.core.presentacion.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author ORFA independiente
 */
public class InterfazFactura extends javax.swing.JFrame {
    private Object labelInfo;
    private BeanUsuario usuarioIF;
    private int anioDeTrabajo;
    
    
    
    
    	  public void main(String[] args) {
    	    //final JTextField txtFecha = new JTextField(20);
    		  txtFecha.setEnabled(false);
    		  
    			  
    	    
    	  }
    	
 // int anioPC = fecha.get(Calendar.YEAR);
    int anioUser=0;
    int mesUser;
    int diaUser;
    float valorProducto;
    int numFactura;
    float totalCategoria;
    float totalVivienda=0;
    float totalAlimentacion=0;
    float totalSalud=0;
    float totalEducacion=0;
    float totalVestimenta=0;
    String error="";


    /**
     * Creates new form factura
     */
    
    public void Datos()
    {
	    OperacionesSQLite op= new OperacionesSQLite();
	    DefaultTableModel model =new DefaultTableModel();
	    tablaFactura.setModel(new DefaultTableModel());
	    model = op.listaFacturas(usuarioIF.getIdUsuario(), anioDeTrabajo);
	    tablaFactura.setModel(model);    
    }
	public void limpiar()
	{
		txtIVA.setText("0.0");
        txtNumFactura.setText("");            
        txtTotal.setText("0.0");
        txtTotalDeducibles.setText("0.0");
        txtTotalAlimentacion.setText("0.0");
        txtTotalEducacion.setText("0.0");
        txtTotalOtros.setText("0.0");
        txtTotalSalud.setText("0.0");
        txtTotalVestimenta.setText("0.0");
        txtTotalVivienda.setText("0.0");
        txtFecha.setText("");
	}     

    
    class RowListener implements ListSelectionListener {
	public void valueChanged(ListSelectionEvent event) {
		try{

			int renglon = tablaFactura.getSelectedRow();
			tablaFactura.isCellEditable(renglon, 0);
			tablaFactura.isCellEditable(renglon, 1);
			tablaFactura.isCellEditable(renglon, 2);
			tablaFactura.isCellEditable(renglon, 3);
			tablaFactura.isCellEditable(renglon, 4);
			tablaFactura.isCellEditable(renglon, 5);
			tablaFactura.isCellEditable(renglon, 6);
			tablaFactura.isCellEditable(renglon, 7);
			tablaFactura.isCellEditable(renglon, 8);
			tablaFactura.isCellEditable(renglon, 9);
			tablaFactura.isCellEditable(renglon, 10);
			tablaFactura.isCellEditable(renglon, 11);

			txtNumFactura.setText(tablaFactura.getValueAt(renglon, 0).toString());
			txtFecha.setText(tablaFactura.getValueAt(renglon, 2).toString());			
			txtTotalVivienda.setText(tablaFactura.getValueAt(renglon, 3).toString());
			txtTotalAlimentacion.setText(tablaFactura.getValueAt(renglon,4).toString());
			txtTotalSalud.setText(tablaFactura.getValueAt(renglon, 5).toString());
			txtTotalEducacion.setText(tablaFactura.getValueAt(renglon, 6).toString());
			txtTotalVestimenta.setText(tablaFactura.getValueAt(renglon, 7).toString());			
			txtTotalOtros.setText(tablaFactura.getValueAt(renglon, 8).toString());
			txtIVA.setText(tablaFactura.getValueAt(renglon,9).toString());
			txtTotalDeducibles.setText(tablaFactura.getValueAt(renglon,10).toString());
			txtTotal.setText(tablaFactura.getValueAt(renglon, 11).toString());


		}
		catch(Exception e)
		{
			System.out.println("");
		}
		
	}
}      
    
    
     public boolean Calculo()
     {
         int anio=anioDeTrabajo;
         OperacionesSQLite op= new OperacionesSQLite();
         //deducibles
         float vi=op.totalVivienda(usuarioIF.getIdUsuario(),anio);
         float al=op.totalAlimentacion(usuarioIF.getIdUsuario(),anio);
         float sa=op.totalSalud(usuarioIF.getIdUsuario(),anio);
         float ed=op.totalEducacion(usuarioIF.getIdUsuario(),anio);
         float ve=op.totalVestimenta(usuarioIF.getIdUsuario(),anio);
         float td=op.totalDeducibles(usuarioIF.getIdUsuario(),anio);
         //no deducibles
         float ot=op.totalOtros(usuarioIF.getIdUsuario(),anio);
         float iv=op.totalIVA(usuarioIF.getIdUsuario(),anio);
         
         //total factura
         float tf=op.totalFacturas(usuarioIF.getIdUsuario(),anio);
                  
         // limites por a�o
         float maxViv=op.maximoViviendaAnio(anio);
         float maxAlim=op.maximoAlimentacionAnio(anio);
         float maxSal=op.maximoSaludAnio(anio);
         float maxEdu=op.maximoEducacionAnio(anio);
         float maxVes=op.maximoVestimentaAnio(anio);
         
         if(vi>maxViv || al>maxAlim || sa>maxSal || ed>maxEdu || ve>maxVes || td>maxSal)
         {
        	//JOptionPane.showMessageDialog(null, "Limites superados ", "",JOptionPane.INFORMATION_MESSAGE);
       		jButton4.setBackground(new java.awt.Color(255, 30, 0));

        	 return true;
         }
         else
         {
        	 jButton4.setBackground(null);
        	 return false;
         }
         /*
         //mensajes
         JOptionPane.showMessageDialog(null, "Total vivienda: "+vi+ " Maximo vivienda: "+ maxViv, "",JOptionPane.INFORMATION_MESSAGE);
         JOptionPane.showMessageDialog(null, "Total alimentacion: "+al+ " Maximo alimentacion : "+maxAlim, "",JOptionPane.INFORMATION_MESSAGE);
         JOptionPane.showMessageDialog(null, "Total salud: "+sa+ " Maximo salud : "+maxSal, "",JOptionPane.INFORMATION_MESSAGE);
         JOptionPane.showMessageDialog(null, "Total educacion: "+ed+ " Maximo educacion : "+maxEdu, "",JOptionPane.INFORMATION_MESSAGE);
         JOptionPane.showMessageDialog(null, "Total vestimenta: "+ve+ " Maximo vestimenta : "+maxVes, "",JOptionPane.INFORMATION_MESSAGE);
         JOptionPane.showMessageDialog(null, "Total deducibles: "+td+ " Maximo deducibles : "+maxSal, "",JOptionPane.INFORMATION_MESSAGE);
         */
     }
     
     Connection cn;
     ResultSet rs;
   public void llenar()
   {
  	 Conexion conexion= new Conexion();
  	 try{
           cn = conexion.enlace(cn);
          
          java.sql.Statement s=cn.createStatement();
        String query = "select * from proveedor";
  rs = s.executeQuery(query);
  comboProveedor.removeAllItems();
   while(rs.next())
          {
             comboProveedor.addItem(rs.getString("nombre_proveedor"));
          }
      s.close();
      cn.close();
      }
       catch(Exception ex)
      {
         JOptionPane.showMessageDialog(null, ex);
      }
   }
     
     
    
   public static boolean isFechaValida(String txtFecha) {
       try {
           SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
           formatoFecha.setLenient(false);
           formatoFecha.parse(txtFecha);
       } catch (ParseException e) {
    	   
           return false;
       }
       return true;
   }
     
    public InterfazFactura(BeanUsuario usuario, int anhio) {
    	
		// TODO Auto-generated constructor stub
    	usuarioIF = usuario;
    	anioDeTrabajo=anhio;
        initComponents();
        limpiar();
        llenar();
        Datos();
        Calculo();
        
	}
	/**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    //@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        labelError = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaFactura = new javax.swing.JTable();
        jButton11 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        txtTotalVivienda = new javax.swing.JTextField();
        txtTotalAlimentacion = new javax.swing.JTextField();
        txtTotalSalud = new javax.swing.JTextField();
        txtIVA = new javax.swing.JTextField();
        txtTotal = new javax.swing.JTextField();
        txtTotalDeducibles = new javax.swing.JTextField();
        txtTotalEducacion = new javax.swing.JTextField();
        txtTotalVestimenta = new javax.swing.JTextField();
        txtTotalOtros = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtNumeroUsuario = new javax.swing.JTextField();
        txtAnioDeTrabajo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        txtNumFactura = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        comboProveedor = new javax.swing.JComboBox();
        txtFecha = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        
        
        
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                int anio=anioDeTrabajo;
                OperacionesSQLite op= new OperacionesSQLite();
                //deducibles
                float vi=op.totalVivienda(usuarioIF.getIdUsuario(),anio);
                float al=op.totalAlimentacion(usuarioIF.getIdUsuario(),anio);
                float sa=op.totalSalud(usuarioIF.getIdUsuario(),anio);
                float ed=op.totalEducacion(usuarioIF.getIdUsuario(),anio);
                float ve=op.totalVestimenta(usuarioIF.getIdUsuario(),anio);
                float td=op.totalDeducibles(usuarioIF.getIdUsuario(),anio);
                //no deducibles
                float ot=op.totalOtros(usuarioIF.getIdUsuario(),anio);
                float iv=op.totalIVA(usuarioIF.getIdUsuario(),anio);
                
                //total factura
                float tf=op.totalFacturas(usuarioIF.getIdUsuario(),anio);
                         
                // limites por a�o
                float maxViv=op.maximoViviendaAnio(anio);
                float maxAlim=op.maximoAlimentacionAnio(anio);
                float maxSal=op.maximoSaludAnio(anio);
                float maxEdu=op.maximoEducacionAnio(anio);
                float maxVes=op.maximoVestimentaAnio(anio);
                
                String supViv="no";
                String supAlim="no";
                String supSal="no";
                String supEdu="no";
                String supVes="no";
                String supDed="no";
                
                if(vi>maxViv)
                {
                	supViv="si";
                }
                if(al>maxAlim)
                {
                	supAlim="si";
                }
                if(sa>maxSal)
                {
                	supSal="si";
                }
                if(ed>maxEdu)
                {
                	supEdu="si";
                }
                if(ve>maxVes)
                {
                	supVes="si";
                }
                if(td>maxSal)
                {
                	supDed="si";
                }
                
                Object[][] rows = {
                	    {"Vivienda",vi,maxViv,supViv},
                	    {"Alimentacion",al,maxAlim,supAlim},
                	    {"Salud",sa,maxSal,supSal},
                	    {"Educacion",ed,maxEdu,supEdu},
                	    {"Vestimenta",ve,maxVes,supVes},
                	    {"Deducibles",td,maxSal,supDed}
                	};
                	Object[] cols = {
                	    "Categoria","Total en este a�o","Limite","Excede el limite"
                	};
                	JTable table = new JTable(rows, cols);
                	JOptionPane.showMessageDialog(null, new JScrollPane(table), "Limites para el a�o "+anio,JOptionPane.INFORMATION_MESSAGE);                
            }
        });
        
        
        
        
        txtNumeroUsuario.setText(usuarioIF.getNombreUsuario());
        txtNumeroUsuario.setEnabled(false);
        txtTotal.setText("0");
        txtTotal.setEnabled(false);
        txtTotalDeducibles.setText("0");
        txtTotalDeducibles.setEnabled(false);
        txtAnioDeTrabajo.setText(String.valueOf(anioDeTrabajo));
        txtAnioDeTrabajo.setEnabled(false);
        
        txtNumFactura.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTotalOtros.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});        
        
        txtIVA.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtIVA.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});
        txtIVA.addFocusListener(new FocusListener() {
        	   public void focusLost(FocusEvent e) {
        		   if(txtTotalVivienda.getText().length()==0)
               	{
                   	txtTotalVivienda.setText("0");                	
               	}
               	if(txtTotalAlimentacion.getText().length()==0)
               	{
               		txtTotalAlimentacion.setText("0");
               	}
               	if(txtTotalSalud.getText().length()==0)
               	{
               		txtTotalSalud.setText("0");
               	}
                   if(txtIVA.getText().length()==0)
               	{
                   	txtIVA.setText("0");
               	}
               	if(txtTotalEducacion.getText().length()==0)
               	{
               		txtTotalEducacion.setText("0");
               	}               	
               	if(txtTotalVestimenta.getText().length()==0)
               	{
               		txtTotalVestimenta.setText("0");
               	}
               	if(txtTotalOtros.getText().length()==0)
               	{
               		txtTotalOtros.setText("0");
               	}
        		   float aa=Float.parseFloat(txtTotalVivienda.getText());
        		   float bb=Float.parseFloat(txtTotalAlimentacion.getText());;
        		   float cc=Float.parseFloat(txtTotalSalud.getText());;
        		   float dd=Float.parseFloat(txtTotalEducacion.getText());;
        		   float ee=Float.parseFloat(txtTotalVestimenta.getText());;
        		   float ff=Float.parseFloat(txtTotalOtros.getText());;
        		   float gg=Float.parseFloat(txtIVA.getText());;
        		   float total=aa+bb+cc+dd+ee+ff+gg;
        		   float totalDeducibles=aa+bb+cc+dd+ee;
        		   txtTotal.setText(Float.toString(total));
        		   txtTotalDeducibles.setText(Float.toString(totalDeducibles));
        	   }
        	   public void focusGained(FocusEvent e) {
        	      // No hacemos nada
        	   }
        	});
        
        txtTotalVivienda.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTotalVivienda.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});        
        txtTotalVivienda.addFocusListener(new FocusListener() {
     	   public void focusLost(FocusEvent e) {
    		   if(txtTotalVivienda.getText().length()==0)
              	{
                  	txtTotalVivienda.setText("0");                	
              	}
              	if(txtTotalAlimentacion.getText().length()==0)
              	{
              		txtTotalAlimentacion.setText("0");
              	}
              	if(txtTotalSalud.getText().length()==0)
              	{
              		txtTotalSalud.setText("0");
              	}
                  if(txtIVA.getText().length()==0)
              	{
                  	txtIVA.setText("0");
              	}
              	if(txtTotalEducacion.getText().length()==0)
              	{
              		txtTotalEducacion.setText("0");
              	}               	
              	if(txtTotalVestimenta.getText().length()==0)
              	{
              		txtTotalVestimenta.setText("0");
              	}
              	if(txtTotalOtros.getText().length()==0)
              	{
              		txtTotalOtros.setText("0");
              	}
       		   float aa=Float.parseFloat(txtTotalVivienda.getText());
       		   float bb=Float.parseFloat(txtTotalAlimentacion.getText());;
       		   float cc=Float.parseFloat(txtTotalSalud.getText());;
       		   float dd=Float.parseFloat(txtTotalEducacion.getText());;
       		   float ee=Float.parseFloat(txtTotalVestimenta.getText());;
       		   float ff=Float.parseFloat(txtTotalOtros.getText());;
       		   float gg=Float.parseFloat(txtIVA.getText());;
       		   float total=aa+bb+cc+dd+ee+ff+gg;
       		   float totalDeducibles=aa+bb+cc+dd+ee;
       		   txtTotal.setText(Float.toString(total));
       		   txtTotalDeducibles.setText(Float.toString(totalDeducibles));
     	   }
     	   public void focusGained(FocusEvent e) {
     	      // No hacemos nada
     	   }
     	});  
        
        txtTotalAlimentacion.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTotalAlimentacion.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});         
        txtTotalAlimentacion.addFocusListener(new FocusListener() {
      	   public void focusLost(FocusEvent e) {
    		   if(txtTotalVivienda.getText().length()==0)
              	{
                  	txtTotalVivienda.setText("0");                	
              	}
              	if(txtTotalAlimentacion.getText().length()==0)
              	{
              		txtTotalAlimentacion.setText("0");
              	}
              	if(txtTotalSalud.getText().length()==0)
              	{
              		txtTotalSalud.setText("0");
              	}
                  if(txtIVA.getText().length()==0)
              	{
                  	txtIVA.setText("0");
              	}
              	if(txtTotalEducacion.getText().length()==0)
              	{
              		txtTotalEducacion.setText("0");
              	}               	
              	if(txtTotalVestimenta.getText().length()==0)
              	{
              		txtTotalVestimenta.setText("0");
              	}
              	if(txtTotalOtros.getText().length()==0)
              	{
              		txtTotalOtros.setText("0");
              	}
       		   float aa=Float.parseFloat(txtTotalVivienda.getText());
       		   float bb=Float.parseFloat(txtTotalAlimentacion.getText());;
       		   float cc=Float.parseFloat(txtTotalSalud.getText());;
       		   float dd=Float.parseFloat(txtTotalEducacion.getText());;
       		   float ee=Float.parseFloat(txtTotalVestimenta.getText());;
       		   float ff=Float.parseFloat(txtTotalOtros.getText());;
       		   float gg=Float.parseFloat(txtIVA.getText());;
       		   float total=aa+bb+cc+dd+ee+ff+gg;
       		   float totalDeducibles=aa+bb+cc+dd+ee;
       		   txtTotal.setText(Float.toString(total));
       		   txtTotalDeducibles.setText(Float.toString(totalDeducibles));
      	   }
      	   public void focusGained(FocusEvent e) {
      	      // No hacemos nada
      	   }
      	});
        txtTotalSalud.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTotalSalud.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});          
        txtTotalSalud.addFocusListener(new FocusListener() {
       	   public void focusLost(FocusEvent e) {
    		   if(txtTotalVivienda.getText().length()==0)
              	{
                  	txtTotalVivienda.setText("0");                	
              	}
              	if(txtTotalAlimentacion.getText().length()==0)
              	{
              		txtTotalAlimentacion.setText("0");
              	}
              	if(txtTotalSalud.getText().length()==0)
              	{
              		txtTotalSalud.setText("0");
              	}
                  if(txtIVA.getText().length()==0)
              	{
                  	txtIVA.setText("0");
              	}
              	if(txtTotalEducacion.getText().length()==0)
              	{
              		txtTotalEducacion.setText("0");
              	}               	
              	if(txtTotalVestimenta.getText().length()==0)
              	{
              		txtTotalVestimenta.setText("0");
              	}
              	if(txtTotalOtros.getText().length()==0)
              	{
              		txtTotalOtros.setText("0");
              	}
       		   float aa=Float.parseFloat(txtTotalVivienda.getText());
       		   float bb=Float.parseFloat(txtTotalAlimentacion.getText());;
       		   float cc=Float.parseFloat(txtTotalSalud.getText());;
       		   float dd=Float.parseFloat(txtTotalEducacion.getText());;
       		   float ee=Float.parseFloat(txtTotalVestimenta.getText());;
       		   float ff=Float.parseFloat(txtTotalOtros.getText());;
       		   float gg=Float.parseFloat(txtIVA.getText());;
       		   float total=aa+bb+cc+dd+ee+ff+gg;
       		   float totalDeducibles=aa+bb+cc+dd+ee;
       		   txtTotal.setText(Float.toString(total));
       		   txtTotalDeducibles.setText(Float.toString(totalDeducibles));
       	   }
       	   public void focusGained(FocusEvent e) {
       	      // No hacemos nada
       	   }
       	});    
        txtTotalEducacion.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTotalEducacion.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});             
        txtTotalEducacion.addFocusListener(new FocusListener() {
        	   public void focusLost(FocusEvent e) {
        		   if(txtTotalVivienda.getText().length()==0)
                  	{
                      	txtTotalVivienda.setText("0");                	
                  	}
                  	if(txtTotalAlimentacion.getText().length()==0)
                  	{
                  		txtTotalAlimentacion.setText("0");
                  	}
                  	if(txtTotalSalud.getText().length()==0)
                  	{
                  		txtTotalSalud.setText("0");
                  	}
                      if(txtIVA.getText().length()==0)
                  	{
                      	txtIVA.setText("0");
                  	}
                  	if(txtTotalEducacion.getText().length()==0)
                  	{
                  		txtTotalEducacion.setText("0");
                  	}               	
                  	if(txtTotalVestimenta.getText().length()==0)
                  	{
                  		txtTotalVestimenta.setText("0");
                  	}
                  	if(txtTotalOtros.getText().length()==0)
                  	{
                  		txtTotalOtros.setText("0");
                  	}
           		   float aa=Float.parseFloat(txtTotalVivienda.getText());
           		   float bb=Float.parseFloat(txtTotalAlimentacion.getText());;
           		   float cc=Float.parseFloat(txtTotalSalud.getText());;
           		   float dd=Float.parseFloat(txtTotalEducacion.getText());;
           		   float ee=Float.parseFloat(txtTotalVestimenta.getText());;
           		   float ff=Float.parseFloat(txtTotalOtros.getText());;
           		   float gg=Float.parseFloat(txtIVA.getText());;
           		   float total=aa+bb+cc+dd+ee+ff+gg;
           		   float totalDeducibles=aa+bb+cc+dd+ee;
           		   txtTotal.setText(Float.toString(total));
           		   txtTotalDeducibles.setText(Float.toString(totalDeducibles));
        	   }
        	   public void focusGained(FocusEvent e) {
        	      // No hacemos nada
        	   }
        	}); 
        txtTotalVestimenta.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTotalVestimenta.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});           
        txtTotalVestimenta.addFocusListener(new FocusListener() {
     	   public void focusLost(FocusEvent e) {
    		   if(txtTotalVivienda.getText().length()==0)
              	{
                  	txtTotalVivienda.setText("0");                	
              	}
              	if(txtTotalAlimentacion.getText().length()==0)
              	{
              		txtTotalAlimentacion.setText("0");
              	}
              	if(txtTotalSalud.getText().length()==0)
              	{
              		txtTotalSalud.setText("0");
              	}
                  if(txtIVA.getText().length()==0)
              	{
                  	txtIVA.setText("0");
              	}
              	if(txtTotalEducacion.getText().length()==0)
              	{
              		txtTotalEducacion.setText("0");
              	}               	
              	if(txtTotalVestimenta.getText().length()==0)
              	{
              		txtTotalVestimenta.setText("0");
              	}
              	if(txtTotalOtros.getText().length()==0)
              	{
              		txtTotalOtros.setText("0");
              	}
       		   float aa=Float.parseFloat(txtTotalVivienda.getText());
       		   float bb=Float.parseFloat(txtTotalAlimentacion.getText());;
       		   float cc=Float.parseFloat(txtTotalSalud.getText());;
       		   float dd=Float.parseFloat(txtTotalEducacion.getText());;
       		   float ee=Float.parseFloat(txtTotalVestimenta.getText());;
       		   float ff=Float.parseFloat(txtTotalOtros.getText());;
       		   float gg=Float.parseFloat(txtIVA.getText());;
       		   float total=aa+bb+cc+dd+ee+ff+gg;
       		   float totalDeducibles=aa+bb+cc+dd+ee;
       		   txtTotal.setText(Float.toString(total));
       		   txtTotalDeducibles.setText(Float.toString(totalDeducibles));
     	   }
     	   public void focusGained(FocusEvent e) {
     	      // No hacemos nada
     	   }
     	});
        txtTotalOtros.addKeyListener(new KeyAdapter()
		{
		   public void keyTyped(KeyEvent e)
		   {
		      char caracter = e.getKeyChar();

		      // Verificar si la tecla pulsada no es un digito
		      if(((caracter < '0') ||
		         (caracter > '9')) &&
		         (caracter != '\b' /*corresponde a BACK_SPACE*/)&&
		         (caracter != '.' /*corresponde a BACK_SPACE*/))
		      {
		         e.consume();  // ignorar el evento de teclado
		      }
		      {if (txtTotalOtros.getText().length()== 13)		    	  
		    	     e.consume();
		    	}
		   }
		});           
        txtTotalOtros.addFocusListener(new FocusListener() {
      	   public void focusLost(FocusEvent e) {
    		   if(txtTotalVivienda.getText().length()==0)
              	{
                  	txtTotalVivienda.setText("0");                	
              	}
              	if(txtTotalAlimentacion.getText().length()==0)
              	{
              		txtTotalAlimentacion.setText("0");
              	}
              	if(txtTotalSalud.getText().length()==0)
              	{
              		txtTotalSalud.setText("0");
              	}
                  if(txtIVA.getText().length()==0)
              	{
                  	txtIVA.setText("0");
              	}
              	if(txtTotalEducacion.getText().length()==0)
              	{
              		txtTotalEducacion.setText("0");
              	}               	
              	if(txtTotalVestimenta.getText().length()==0)
              	{
              		txtTotalVestimenta.setText("0");
              	}
              	if(txtTotalOtros.getText().length()==0)
              	{
              		txtTotalOtros.setText("0");
              	}
       		   float aa=Float.parseFloat(txtTotalVivienda.getText());
       		   float bb=Float.parseFloat(txtTotalAlimentacion.getText());;
       		   float cc=Float.parseFloat(txtTotalSalud.getText());;
       		   float dd=Float.parseFloat(txtTotalEducacion.getText());;
       		   float ee=Float.parseFloat(txtTotalVestimenta.getText());;
       		   float ff=Float.parseFloat(txtTotalOtros.getText());;
       		   float gg=Float.parseFloat(txtIVA.getText());;
       		   float total=aa+bb+cc+dd+ee+ff+gg;
       		   float totalDeducibles=aa+bb+cc+dd+ee;
    		   txtTotal.setText(Float.toString(total));
    		   txtTotalDeducibles.setText(Float.toString(totalDeducibles));
      	   }
      	   public void focusGained(FocusEvent e) {
      	      // No hacemos nada
      	   }
      	});            

        
        
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        //this.setLocationRelativeTo(null);
        setTitle("Gestion de Facturas");
        jButton1.setBackground(new java.awt.Color(204, 255, 204));
        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	
            	//InterfazMaximos c1=new InterfazMaximos(usuarioIF); 
  			  //c1.modificarValorVar1(anioDeTrabajo); 
  			    int valorVar1= Integer.parseInt(txtAnioDeTrabajo.getText());
  			  
            	String var1=txtFecha.getText();
            	try{
            	int var2 = Integer.parseInt(var1.substring(6,10));
            	               
            	if(valorVar1==var2){
            	isFechaValida(error);
                jButton1ActionPerformed(evt);
                String error="no";
                String mensajeError="";
                if(txtTotalVivienda.getText().length()==0)
            	{
                	txtTotalVivienda.setText("0");                	
            	}
            	if(txtTotalAlimentacion.getText().length()==0)
            	{
            		txtTotalAlimentacion.setText("0");
            	}
            	if(txtTotalSalud.getText().length()==0)
            	{
            		txtTotalSalud.setText("0");
            	}
                if(txtIVA.getText().length()==0)
            	{
                	txtIVA.setText("0");
            	}
            	if(txtTotalEducacion.getText().length()==0)
            	{
            		txtTotalEducacion.setText("0");
            	}               	
            	if(txtTotalVestimenta.getText().length()==0)
            	{
            		txtTotalVestimenta.setText("0");
            	}
            	if(txtTotalOtros.getText().length()==0)
            	{
            		txtTotalOtros.setText("0");
            	}
            	if(txtNumeroUsuario.getText().length()==0)
            	{
            		mensajeError=mensajeError+"ERROR AL IDENTIFICAR AL ACTUAL USUARIO\n";
            		//JOptionPane.showMessageDialog(null, "ERROR AL IDENTIFICAR AL ACTUAL USUARIO", "Registro de Proveedor", JOptionPane.ERROR_MESSAGE);
            		error="si";
            	}
                if(txtNumFactura.getText().length()==0)
            	{
                	mensajeError=mensajeError+"Ingrese el numero de su factura\n";
            		//JOptionPane.showMessageDialog(null, "Ingrese el numero de su factura", "Registro de Proveedor", JOptionPane.ERROR_MESSAGE);
            		error="si";
            	}
            	if(txtFecha.getText().length()==0)
            	{
                	mensajeError=mensajeError+"Ingrese la fecha de su factura\n";
            		//JOptionPane.showMessageDialog(null, "Ingrese la fecha de su factura", "Registro de Proveedor", JOptionPane.ERROR_MESSAGE);
            		error="si";
            	}
            	float x=Float.parseFloat(txtTotal.getText());
                if(x==0.0)
            	{
                	mensajeError=mensajeError+"NO PUEDE INGRESAR UNA FACTURA VACIA\n";
                	//JOptionPane.showMessageDialog(null, "NO PUEDE INGRESAR UNA FACTURA VACIA", "ERROR", JOptionPane.ERROR_MESSAGE);
                	error="si";
            	}
                try
                {
                	comboProveedor.getSelectedItem().toString().length();
                }
            	catch (Exception exx)
            	{
            		mensajeError=mensajeError+"INGRESE UN PROVEEDOR ANTES DE INGRESAR LA FACTURA\n";
            		//JOptionPane.showMessageDialog(null, "INGRESE UN PROVEEDOR ANTES DE INGRESAR LA FACTURA", "ERROR", JOptionPane.ERROR_MESSAGE);
            		error="si";
            	}

            	if(error=="no")
            	{
    				BeanFactura bf = new BeanFactura();
    				bf.setNumeroFactura(Integer.parseInt(txtNumFactura.getText()));
    				bf.setFechaFactura(txtFecha.getText());
        			bf.setTotalVivienda(Float.parseFloat(txtTotalVivienda.getText()));
                	bf.setTotalAlimentacion(Float.parseFloat(txtTotalAlimentacion.getText()));
                    bf.setTotalSalud(Float.parseFloat(txtTotalSalud.getText()));                 
    				bf.setTotalEducacion(Float.parseFloat(txtTotalEducacion.getText()));
        			bf.setTotalVestimenta(Float.parseFloat(txtTotalVestimenta.getText()));
                	bf.setTotalOtros(Float.parseFloat(txtTotalOtros.getText()));
                    bf.setTotalIVA(Float.parseFloat(txtIVA.getText())); 
                    bf.setTotalDeducibles(Float.parseFloat(txtTotalDeducibles.getText()));
    				bf.setTotalFactura(Float.parseFloat(txtTotal.getText()));
    				
        			bf.setUsuario(usuarioIF.getIdUsuario());
        			OperacionesSQLite op1= new OperacionesSQLite();
        			bf.setProveedor(op1.tomarIdProveedor(comboProveedor.getSelectedItem().toString()));
                	bf.setAno(Integer.parseInt(txtAnioDeTrabajo.getText()));
            		
                	OperacionesSQLite.insertarFactura(bf);
                	Datos();
                    Calculo();
            	}
            	else
            	{
            		JOptionPane.showMessageDialog(null, mensajeError, "ERROR", JOptionPane.ERROR_MESSAGE);
            	}
            }
            	else{
            		String nl = System.getProperty("line.separator");
                	JOptionPane.showMessageDialog(null,"El a�o no corresponde al A�o Fiscal"+ nl + "Porfavor Corrijalo"); 
            }
        }catch (Exception e) {
        	JOptionPane.showMessageDialog(null,"Formato de a�o no valido"); 
      	   
            }  
            
            }
            
        });
        
		JButton btnNewButton_1 = new JButton("VER TODAS MIS FACTURAS");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				//InterfazFactura jFactura= new InterfazFactura(usuarioIF, anioDeTrabajo);
		        //jFactura.setVisible(true);
				
				InterfazVerFacturas fac = new InterfazVerFacturas(usuarioIF);
				fac.setVisible(true);

			}
		});
		JButton btnfecha = new JButton("Fecha");
		btnfecha.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				//InterfazFactura jFactura= new InterfazFactura(usuarioIF, anioDeTrabajo);
		        //jFactura.setVisible(true);
				
				InterfazVerFacturas fac = new InterfazVerFacturas(usuarioIF);
				fac.setVisible(true);

			}
		});
		//btnNewButton_1.setBounds(175, 223, 124, 37);
		//tablaFactura.add(btnNewButton_1);

        tablaFactura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tablaFactura);
        tablaFactura.getAccessibleContext().setAccessibleDescription("");
	    tablaFactura.getSelectionModel().addListSelectionListener(new InterfazFactura.RowListener());

        jButton11.setText("Eliminar");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
                if(txtNumFactura.getText().length()==0)
                {
                	JOptionPane.showMessageDialog(null, "INGRESE EL NUMERO DE FACTURA A ELIMINAR", "Eliminar Factura", JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                	OperacionesSQLite op1= new OperacionesSQLite();
                	OperacionesSQLite.eliminarFactura(Integer.parseInt(txtNumFactura.getText()),usuarioIF.getIdUsuario(), op1.tomarIdProveedor(comboProveedor.getSelectedItem().toString()));
                	Datos();
                    Calculo();

                }
            }
        });

       
        jButton2.setText("Editar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	
                jButton2ActionPerformed(evt);
                
                int valorVar1= Integer.parseInt(txtAnioDeTrabajo.getText()); 
            	String var1=txtFecha.getText();
            	try{
            	int var2 = Integer.parseInt(var1.substring(6,10));               
            	if(valorVar1==var2){
            	isFechaValida(error);
            	                
            	if(comboProveedor.getSelectedItem().toString().length()>0)
            	{
                    String error="no";
                    String mensajeError="";
                    
                    if(txtTotalVivienda.getText().length()==0)
                	{
                    	txtTotalVivienda.setText("0");                	
                	}
                	if(txtTotalAlimentacion.getText().length()==0)
                	{
                		txtTotalAlimentacion.setText("0");
                	}
                	if(txtTotalSalud.getText().length()==0)
                	{
                		txtTotalSalud.setText("0");
                	}
                    if(txtIVA.getText().length()==0)
                	{
                    	txtIVA.setText("0");
                	}
                	if(txtTotalEducacion.getText().length()==0)
                	{
                		txtTotalEducacion.setText("0");
                	}               	
                	if(txtTotalVestimenta.getText().length()==0)
                	{
                		txtTotalVestimenta.setText("0");
                	}
                	if(txtTotalOtros.getText().length()==0)
                	{
                		txtTotalOtros.setText("0");
                	}
                	if(txtNumeroUsuario.getText().length()==0)
                	{
                		mensajeError=mensajeError+"ERROR AL IDENTIFICAR AL ACTUAL USUARIO\n";
                		//JOptionPane.showMessageDialog(null, "ERROR AL IDENTIFICAR AL ACTUAL USUARIO", "Registro de Proveedor", JOptionPane.ERROR_MESSAGE);
                		error="si";
                	}
                    if(txtNumFactura.getText().length()==0)
                	{
                		mensajeError=mensajeError+"Ingrese el numero de su factura\n";
                		//JOptionPane.showMessageDialog(null, "Ingrese el numero de su factura", "Registro de Proveedor", JOptionPane.ERROR_MESSAGE);
                		error="si";
                	}
                	if(txtFecha.getText().length()==0)
                	{
                		mensajeError=mensajeError+"Ingrese la fecha de su factura\n";
                		//JOptionPane.showMessageDialog(null, "Ingrese la fecha de su factura", "Registro de Proveedor", JOptionPane.ERROR_MESSAGE);
                		error="si";
                	}
                	float x=Float.parseFloat(txtTotal.getText());
                    if(x==0.0)
                	{
                		mensajeError=mensajeError+"NO PUEDE INGRESAR UNA FACTURA VACIA\n";
                    	//JOptionPane.showMessageDialog(null, "NO PUEDE INGRESAR UNA FACTURA VACIA", "ERROR", JOptionPane.ERROR_MESSAGE);
                    	error="si";
                	}            	
                	if(comboProveedor.getSelectedItem().toString().length()==0)
                	{
                		mensajeError=mensajeError+"INGRESE UN PROVEEDOR ANTES DE INGRESAR LA FACTURA\n";
                		//JOptionPane.showMessageDialog(null, "INGRESE UN PROVEEDOR ANTES DE INGRESAR LA FACTURA", "ERROR", JOptionPane.ERROR_MESSAGE);
                		error="si";
                	}
                	if(error=="no")
                	{
        				BeanFactura bf = new BeanFactura();
        				bf.setNumeroFactura(Integer.parseInt(txtNumFactura.getText()));
        				bf.setFechaFactura(txtFecha.getText());
            			bf.setTotalVivienda(Float.parseFloat(txtTotalVivienda.getText()));
                    	bf.setTotalAlimentacion(Float.parseFloat(txtTotalAlimentacion.getText()));
                        bf.setTotalSalud(Float.parseFloat(txtTotalSalud.getText()));                 
        				bf.setTotalEducacion(Float.parseFloat(txtTotalEducacion.getText()));
            			bf.setTotalVestimenta(Float.parseFloat(txtTotalVestimenta.getText()));
                    	bf.setTotalOtros(Float.parseFloat(txtTotalOtros.getText()));
                        bf.setTotalIVA(Float.parseFloat(txtIVA.getText())); 
                        bf.setTotalDeducibles(Float.parseFloat(txtTotalDeducibles.getText()));
        				bf.setTotalFactura(Float.parseFloat(txtTotal.getText()));
        				
            			bf.setUsuario(usuarioIF.getIdUsuario());
            			OperacionesSQLite op1= new OperacionesSQLite();
            			bf.setProveedor(op1.tomarIdProveedor(comboProveedor.getSelectedItem().toString()));
                    	bf.setAno(Integer.parseInt(txtAnioDeTrabajo.getText()));
                		
                		OperacionesSQLite.actualizarFactura(bf);
                    	Datos();
                        Calculo();

                	}
                	else
                	{
                		JOptionPane.showMessageDialog(null, mensajeError, "ERROR", JOptionPane.ERROR_MESSAGE);
                	}

            	}                
            }
            else{
        		String nl = System.getProperty("line.separator");
            	JOptionPane.showMessageDialog(null,"El a�o no corresponde al A�o Fiscal"+ nl + "Porfavor Corrijalo"); 
            }
            	}catch (Exception e) {
            		JOptionPane.showMessageDialog(null,"Formato de a�o no valido"); 
                }
            }
        });
        
      

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText("    G E S T I O N    D E   F A C T U R A S");

        jButton3.setText("Limpiar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
        	public void actionPerformed(java.awt.event.ActionEvent evt) {
        	jButton3ActionPerformed(evt);
        	limpiar();

        	}
        });

    
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("TOTAL"));

        jLabel14.setText("Otros");

        jLabel15.setText("Vivienda");

        jLabel16.setText("Alimentaci�n");

        jLabel17.setText("Salud");

        jLabel24.setText("Educaci�n");

        jLabel25.setText("Vestimenta");

        jLabel27.setText("IVA");
        
        jLabel69.setText("Total deducibles");

        jLabel28.setText("Total factura");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17)
                    .addComponent(jLabel27)
                    .addComponent(jLabel69)
                    .addComponent(jLabel28)
                    .addComponent(jLabel15))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtIVA, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTotalVivienda, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTotalAlimentacion, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTotalSalud, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTotalDeducibles, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(84, 84, 84)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(44, 44, 44)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTotalVestimenta)
                            .addComponent(txtTotalOtros)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                        .addComponent(txtTotalEducacion, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel24)
                    .addComponent(txtTotalVivienda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotalEducacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel25)
                    .addComponent(txtTotalAlimentacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotalVestimenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jLabel14)
                    .addComponent(txtTotalSalud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotalOtros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(txtIVA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel69)
                    .addComponent(txtTotalDeducibles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel6.setText("Ingresar fecha de factura");

        txtNumeroUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumeroUsuarioActionPerformed(evt);
            }
        });

        jLabel5.setText("Nombre Usuario");
        jLabel70.setText("A�o de trabajo");
        
        txtNumFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumFacturaActionPerformed(evt);
            }
        });

        jLabel1.setText("Escoja un proveedor");

        jLabel2.setText("Ingrese el numero de factura");

        comboProveedor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", " " }));
        comboProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboProveedorActionPerformed(evt);
            }
        });
        
        JButton btnFecha = new JButton("Fecha");
        btnFecha.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        			  
        		JLabel label = new JLabel("Seleccionar Fecha:");
        	    final JTextField text = new JTextField(20);
        	    JButton b = new JButton("Seleccionar");
        	    JPanel p = new JPanel();
        	    p.add(label);
        	    p.add(text);
        	    p.add(b);
        	    final JFrame f = new JFrame();
        	    f.getContentPane().add(p);
        	    f.pack();
        	    f.setVisible(true);
        	    b.addActionListener(new ActionListener() {
        	      public void actionPerformed(ActionEvent ae) {
        	        text.setText(new DatePicker(f).setPickedDate());
        			        txtFecha.setText( text.getText() );
        			      }
        			    });
        			  }
        	
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2Layout.setHorizontalGroup(
        	jPanel2Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel2Layout.createSequentialGroup()
        			.addGap(31)
        			.addGroup(jPanel2Layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(jLabel2)
        				.addGroup(jPanel2Layout.createSequentialGroup()
        					.addGroup(jPanel2Layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(jLabel6)
        						.addGroup(jPanel2Layout.createSequentialGroup()
        							.addGroup(jPanel2Layout.createParallelGroup(Alignment.LEADING)
        								.addComponent(jLabel5)
        								.addComponent(jLabel70)
        								.addComponent(jLabel1))
        							.addGap(73)
        							.addGroup(jPanel2Layout.createParallelGroup(Alignment.TRAILING, false)
        								.addComponent(comboProveedor, Alignment.LEADING, 0, 127, Short.MAX_VALUE)
        								.addComponent(txtFecha, Alignment.LEADING)
        								.addComponent(txtNumFactura, Alignment.LEADING)
        								.addComponent(txtAnioDeTrabajo)
        								.addComponent(txtNumeroUsuario))))
        					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addComponent(btnFecha, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)))
        			.addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
        	jPanel2Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel2Layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(jPanel2Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(txtAnioDeTrabajo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel70))
        			.addGap(18)
        			.addGroup(jPanel2Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(txtNumeroUsuario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel5))
        			.addGap(18)
        			.addGroup(jPanel2Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel1)
        				.addComponent(comboProveedor, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addGap(18)
        			.addGroup(jPanel2Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel2)
        				.addComponent(txtNumFactura, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addGap(18)
        			.addGroup(jPanel2Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel6)
        				.addComponent(txtFecha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnFecha))
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2.setLayout(jPanel2Layout);

        jButton4.setText("Ver Limites");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(339, 339, 339)
                .addComponent(labelError)
                .addGap(23, 641, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(46, 46, 46))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jScrollPane2)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60)
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(180, 180, 180))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addGap(50, 50, 50)
                        .addComponent(btnNewButton_1)
                        .addGap(310, 310, 310)))));
                        //.addComponent(btnNewButton_1)
                        //.addGap(410, 410, 410))));
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelError)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton11)
                            .addComponent(jButton3)
                            .addComponent(jButton2))
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton4)
                //.addGap(22, 22, 22)
                .addComponent(btnNewButton_1))
                .addGap(22,22, 22))
                //.addGap(10, 10, 10)
        );

        pack();
    }// </editor-fold>                        







	private void comboProveedorActionPerformed(java.awt.event.ActionEvent evt) {                                               
        // TODO add your handling code here:
        
    }                                              

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Calendar fecha = Calendar.getInstance();
        int anioPC = fecha.get(Calendar.YEAR);
       /*
        int anioPC = fecha.get(Calendar.YEAR);
        int anioUser=0;
        int mesUser;
        int diaUser;
        int valorProducto;
        int numFactura;
        float totalCategoria;
        float totalVivienda=0;
        float totalAlimentacion=0;
        float totalSalud=0;
        float totalEducacion=0;
        float totalVestimenta=0;
        String error="";
        */
 
    }//GEN-LAST:event_jButton1ActionPerformed
    
    private void txtNumFacturaActionPerformed(java.awt.event.ActionEvent evt) {                                              
        // TODO add your handling code here:
    }                                             

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {                                               

        //String nombre;
        //nombre=tablaFactura.getValueAt(tablaFactura.getSelectedRow(), 0).toString();
        //BeanFactura bf=new BeanFactura();
        //bf.Eliminar(nombre);
        //Datos();
         //Calculo();
    }                                              
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton1ActionPerformed  
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
 
    }                                        

    private void txtNumeroUsuarioActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        // TODO add your handling code here:
    }                                                

    /**
     * @param args the command line arguments
     */
    /*public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         *
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form /
        java.awt.EventQueue.invokeLater(new Runnable() {

			public void run() {
                new InterfazFactura().setVisible(true);
            }
        });
    }*/

    // Variables declaration - do not modify                     
    private javax.swing.JComboBox comboProveedor;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jButton11;
    private javax.swing.JLabel labelError;
    private javax.swing.JTable tablaFactura;
    private javax.swing.JTextField txtIVA;
    private javax.swing.JTextField txtNumFactura;
    private javax.swing.JTextField txtNumeroUsuario;
    private javax.swing.JTextField txtAnioDeTrabajo;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtTotalDeducibles;
    private javax.swing.JTextField txtTotalAlimentacion;
    private javax.swing.JTextField txtTotalEducacion;
    private javax.swing.JTextField txtTotalOtros;
    private javax.swing.JTextField txtTotalSalud;
    private javax.swing.JTextField txtTotalVestimenta;
    private javax.swing.JTextField txtTotalVivienda;
    private javax.swing.JTextField txtFecha;
}
