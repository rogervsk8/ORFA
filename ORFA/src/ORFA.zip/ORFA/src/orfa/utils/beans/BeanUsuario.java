/* Esta clase pertenece al grupo de clases que seran utilizados para realizar el mapeo con la BD, 
 * en particular esta clase es la responsable del mapeo de los distintos componentes con la tabla usuarios que se encuentra la BD.
 */
package orfa.utils.beans;

public class BeanUsuario {
	// atributos de la clase
	private int idUsuario;
	private String cedulaUsuario = null, nombreUsuario = null, apellidoUsuario = null,
			nickUsuario = null, passUsuario = null, emailUsuario = null;
	private float salarioAnual;
	public String getCedulaUsuario() {
		return cedulaUsuario;
	}
	public void setCedulaUsuario(String cedulaUsuario) {
		this.cedulaUsuario = cedulaUsuario;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public String getApellidoUsuario() {
		return apellidoUsuario;
	}
	public void setApellidoUsuario(String apellidoUsuario) {
		this.apellidoUsuario = apellidoUsuario;
	}
	public String getNickUsuario() {
		return nickUsuario;
	}
	public void setNickUsuario(String nickUsuario) {
		this.nickUsuario = nickUsuario;
	}
	public String getPassUsuario() {
		return passUsuario;
	}
	public void setPassUsuario(String passUsuario) {
		this.passUsuario = passUsuario;
	}
	public String getEmailUsuario() {
		return emailUsuario;
	}
	public void setEmailUsuario(String emailUsuario) {
		this.emailUsuario = emailUsuario;
	}
	public float getSalarioAnual() {
		return salarioAnual;
	}
	public void setSalarioAnual(float salarioAnual) {
		this.salarioAnual = salarioAnual;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public int getIdUsuario() {
		return idUsuario;
	}

	

}