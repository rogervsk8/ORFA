package orfa.utils.beans;

import javax.swing.table.DefaultTableModel;

public class BeanProveedor {

	private int idProveedor;
	
	public void setIdProveedor(int idProveedor) {
		this.idProveedor = idProveedor;
	}

	private String rucProveedor = null, nombreProveedor = null,
			ciudadProveedor = null, direccionProveedor = null,
			telefonoProveedor = null;

	public String getRucProveedor() {
		return rucProveedor;
	}

	public void setRucProveedor(String rucProveedor) {
		this.rucProveedor = rucProveedor;
	}

	public String getNombreProveedor() {
		return nombreProveedor;
	}

	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}

	public String getCiudadProveedor() {
		return ciudadProveedor;
	}

	public void setCiudadProveedor(String ciudadProveedor) {
		this.ciudadProveedor = ciudadProveedor;
	}

	public String getDireccionProveedor() {
		return direccionProveedor;
	}

	public void setDireccionProveedor(String direccionProveedor) {
		this.direccionProveedor = direccionProveedor;
	}

	public String getTelefonoProveedor() {
		return telefonoProveedor;
	}

	public void setTelefonoProveedor(String telefonoProveedor) {
		this.telefonoProveedor = telefonoProveedor;
	}

	public int getIdProveedor() {
		return idProveedor;
	}
     
	public DefaultTableModel lista2(String text) {
		// TODO Auto-generated method stub
		return null;
	}

}