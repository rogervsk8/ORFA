/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orfa.utils.datos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import orfa.core.datos.Conexion;

/**
 * 
 * @author 
 */
public class DatosUsuario {

	// creamos las variables para la conexion
	static Connection cn;
	static Statement s;
	static ResultSet rs;

	// creamos metodo para insertar datos
	public void agregarUsuario(String ruc_usuario, String nick_usuario,
			String nombre_usuario, String apellido_usuario,
			String password_usuario, double salario_usuario,
			String correo_usuario, String pregunta, String respuesta) {

		try {

			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			String query = "INSERT INTO usuario values (null, '" + ruc_usuario
					+ "','" + nick_usuario + "','" + nombre_usuario + "','"
					+ apellido_usuario + "','" + password_usuario + "','"
					+ salario_usuario + "','" + correo_usuario + "','"
					+ pregunta + "','" + respuesta + "');";
			// System.out.println(query);
			s.executeUpdate(query);
			s.close();
			cn.close();

			JOptionPane.showMessageDialog(null, "Usuario ingresado exitosamente");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "El nick de usuario que esta intentado utilizar ya existe, por favor utilice uno diferente.", "Nick de usuario",JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public void actualizarUsuario(String ruc_usuario, String nick_usuario,
			String nombre_usuario, String apellido_usuario,
			String password_usuario, double salario_usuario,
			String correo_usuario, String pregunta, String respuesta) {
		try {

			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();

			String query = "UPDATE usuario SET ruc_usuario = '" + ruc_usuario
					+ "' , nick_usuario = '" + nick_usuario
					+ "' , nombre_usuario = '" + nombre_usuario
					+ "' , apellido_usuario = '" + apellido_usuario
					+ "' , password_usuario = '" + password_usuario
					+ "' , salario_usuario = '" + salario_usuario
					+ "' , correo_usuario = '" + correo_usuario
					+ "' , pregunta_usuario = '" + pregunta
					+ "' , respuesta_usuario = '" + respuesta
					+ "'where ruc_usuario ='" + ruc_usuario + "'";

			// System.out.println(query);
			s.executeUpdate(query);
			s.close();
			cn.close();
			JOptionPane.showMessageDialog(null, "Usuario ha sido actualizado");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	public void actualizarUsuarioContasenia(String nick_usuario,
			String password_usuario) {
		// dentro de try cacht por si los errores
		try {

			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			String query = "UPDATE usuario SET password_usuario ='"
					+ password_usuario + "'where nick_usuario ='"
					+ nick_usuario + "'";
			// System.out.println(query);
			s.executeUpdate(query);
			s.close();
			cn.close();
			JOptionPane.showMessageDialog(null,
					"La contrase�a del usuario ha sido actualizada");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

}