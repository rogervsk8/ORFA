package orfa.utils.validacion;

/**
 * @author efesan En esta clase se definen los metodos que llevan a cabo el
 *         trabajo de validar un numero de cedula dado. Los metodos son
 *         estaticos y por lo tanto su uso no requiere de instaciar un objeto de
 *         la clase.
 */
public class ValidadorCedula {

	/**
	 * @param cedula
	 *            Este parametro corresponde al string del numero de cedula del
	 *            cual se quiere evaluar su validez.
	 * @return esCedula Este valor de retorno es un booleano el cual informa si
	 *         el numero de cedula dado es valido (true) o no (false).
	 */
	public static boolean validarCedula(String cedula) {

		boolean esCedula = true;

		if (!validarCodigoProvincia(cedula) || !validarTercerDigito(cedula)
				|| !validarDigitoVerificador(cedula)) {
			esCedula = false;
			return esCedula;
		}
		return esCedula;
	}

	/**
	 * @param cedula
	 *            Este parametro corresponde al string del numero de cedula del
	 *            cual se quiere evaluar su validez.
	 * @return esTercerDigito Este valor de retorno es un booleano el cual
	 *         informa si el tercer digito del numero de cedula dado se
	 *         corresponde con algun valor adecuado.
	 */
	private static boolean validarTercerDigito(String cedula) {

		boolean esTercerDigito = true;
		int tercerDigito;

		tercerDigito = Integer.parseInt(cedula.substring(2, 3));
		if (tercerDigito == 7 || tercerDigito == 8) {
			esTercerDigito = false;
			return esTercerDigito;
		}
		return esTercerDigito;
	}

	private static boolean validarCodigoProvincia(String cedula) {

		boolean esCodigoProvincia = true;
		int codigoProvincia;

		codigoProvincia = Integer.parseInt(cedula.substring(0, 2));
		if (codigoProvincia <= 0 || codigoProvincia > 24) {
			esCodigoProvincia = false;
			return esCodigoProvincia;
		}
		return esCodigoProvincia;
	}

	private static boolean validarDigitoVerificador(String cedula) {

		boolean esDigitoVerificador = true;
		int digitoVerificador, i, doblarImpar, sumaPares = 0, sumaImpares = 0, sumaParesImpares, decenaSuperior, digitoResultante;

		for (i = 0; i < 9; i++) {
			if (i % 2 == 0) {
				doblarImpar = 2 * Integer.parseInt(cedula.substring(i, i + 1));
				if (doblarImpar >= 10)
					doblarImpar = doblarImpar - 9;
				sumaImpares = sumaImpares + doblarImpar;
			} else {
				sumaPares = sumaPares
						+ Integer.parseInt(cedula.substring(i, i + 1));
			}
		}
		sumaParesImpares = sumaPares + sumaImpares;
		decenaSuperior = sumaParesImpares - (sumaParesImpares % 10) + 10;
		digitoResultante = decenaSuperior - sumaParesImpares;
		digitoVerificador = Integer.parseInt(cedula.substring(9));
		// System.out.println(sumaParesImpares);
		if (digitoResultante != digitoVerificador) {
			esDigitoVerificador = false;
			return esDigitoVerificador;
		}
		return esDigitoVerificador;
	}

}