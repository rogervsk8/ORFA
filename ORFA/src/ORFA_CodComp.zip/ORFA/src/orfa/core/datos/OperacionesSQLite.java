package orfa.core.datos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import orfa.utils.beans.BeanFactura;
import orfa.utils.beans.BeanProveedor;
import orfa.utils.beans.BeanUsuario;

public class OperacionesSQLite {

	private static Connection cn = null;
	private static Statement stmt = null;
	DefaultTableModel modelo = new DefaultTableModel();
	
	public DefaultTableModel listaProveedor() {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			String query = "SELECT ruc_proveedor as'RUC PROVEEDOR' , nombre_proveedor as 'NOMBRE', ciudad_proveedor as 'CIUDAD', direccion_proveedor as 'DIRECCION', telefono_proveedor as 'TELEFONO' from proveedor";
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}


	public static void insertarUsuario(BeanUsuario bnUsuario) {

		try {
			//Connection cn = ConexionBD.conexionSQLite();
			cn = Conexion.enlace(cn);
			Statement stmt = cn.createStatement();
			String sql = "INSERT INTO USUARIO (ruc_usuario, nick_usuario, nombre_usuario, apellido_usuario, pasword_usuario, salario_usuario, correo_usuario) "
					+ "VALUES ('"
					+ bnUsuario.getCedulaUsuario()
					+ "','"
					+ bnUsuario.getNickUsuario()
					+ "','"
					+ bnUsuario.getNombreUsuario()
					+ "','"
					+ bnUsuario.getApellidoUsuario()
					+ "','"
					+ bnUsuario.getPassUsuario()
					+ "','"
					+ bnUsuario.getSalarioAnual()
					+ "','"
					+ bnUsuario.getEmailUsuario() + "')";
			stmt.executeUpdate(sql);
			stmt.close();
			// cn.commit();
			cn.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	public ResultSet consulta(String queryBusqueda) {
		Statement comando;
		ResultSet resultado = null;
		try {
			comando = cn.createStatement();
			resultado = comando.executeQuery(queryBusqueda);

		} catch (SQLException e) {
			e.getSQLState();
			String message = "Error en query stament " + e.getMessage()
					+ "<p><b>Error codigo: </b>" + e.getErrorCode()
					+ " </p></html>";
			//System.out.println(queryBusqueda);
			JOptionPane.showMessageDialog(new JFrame(), message);
		}
		return resultado;
	}

	public boolean siguiente(ResultSet rs) {
		try {
			return rs.next();
		} catch (SQLException error) {
			return false;
		}
	}


	public static void insertarProveedor(BeanProveedor bnProveedor) {

		ResultSet rs = null;

		try {
			//cn = ConexionBD.conexionSQLite();
			cn = Conexion.enlace(cn);
			stmt = cn.createStatement();
			String sql = "SELECT * FROM proveedor WHERE ruc_proveedor='"
					+ bnProveedor.getRucProveedor() + "'";
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				JOptionPane.showMessageDialog(null, "El proveedor ya existe",
						"Registro de Proveedor",
						JOptionPane.INFORMATION_MESSAGE);
			} else {
				sql = "INSERT INTO proveedor (ruc_proveedor, nombre_proveedor, ciudad_proveedor, direccion_proveedor, telefono_proveedor) "
						+ "VALUES ('"
						+ bnProveedor.getRucProveedor()
						+ "','"
						+ bnProveedor.getNombreProveedor()
						+ "','"
						+ bnProveedor.getCiudadProveedor()
						+ "','"
						+ bnProveedor.getDireccionProveedor()
						+ "','"
						+ bnProveedor.getTelefonoProveedor() + "')";
				stmt.executeUpdate(sql);
				stmt.close();
				JOptionPane.showMessageDialog(null,
						"Proveedor ingresado exitosamente",
						"Registro de Proveedor",
						JOptionPane.INFORMATION_MESSAGE);
			}
			cn.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		//System.out.println("Records created successfully");

	}

	public static void eliminarUsuario(BeanUsuario bnUsuario) {

		try {
			//cn = ConexionBD.conexionSQLite();
			cn = Conexion.enlace(cn);
			stmt = cn.createStatement();
			String sql = "DELETE from USUARIO where ID = "
					+ bnUsuario.getIdUsuario() + ";";
			stmt.executeUpdate(sql);
			stmt.close();
			cn.commit();
			cn.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}


	public static void eliminarProveedor(String ruuc) {

		ResultSet rs = null;

		try {
			//cn = ConexionBD.conexionSQLite();
			cn = Conexion.enlace(cn);
			stmt = cn.createStatement();
			String sql = "SELECT * FROM factura WHERE proveedor_id_proveedor=(SELECT id_proveedor FROM proveedor WHERE ruc_proveedor='"
					+ ruuc + "')";
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				JOptionPane.showMessageDialog(null,
						"Existen facturas con ese proveedor",
						"Eliminar Proveedor", JOptionPane.INFORMATION_MESSAGE);
			} else {
				sql = "delete from proveedor where ruc_proveedor='" + ruuc
						+ "'";
				stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(null,
						"Proveedor eliminado con exito", "Eliminar Proveedor",
						JOptionPane.INFORMATION_MESSAGE);
			}
			 stmt.close();
			cn.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	
	public String getString(ResultSet datos, String columna) {

		try {
			return datos.getString(columna);
		} catch (SQLException error) {

			String message = "<html><p><b>Error de Mysql: </b> "
					+ error.getMessage() + "</p> " + "<p><b>Error código: </b>"
					+ error.getErrorCode() + " </p></html>";
			JOptionPane.showMessageDialog(new JFrame(), message);
			return (null);
		}
	}

	
    public static void actualizarProveedor(BeanProveedor bnProveedor) {
            
        ResultSet rs = null;
	
            try {
		//cn = ConexionBD.conexionSQLite();
            	cn = Conexion.enlace(cn);
		stmt = cn.createStatement();
                    String sql = "SELECT * FROM proveedor WHERE ruc_proveedor='"
				+ bnProveedor.getRucProveedor() + "'"; 
                    rs = stmt.executeQuery(sql);
                    
                    if ( rs.next() ) 
                    {
                        sql = "UPDATE proveedor SET nombre_proveedor= '"+ bnProveedor.getNombreProveedor() + "' WHERE ruc_proveedor='"+ bnProveedor.getRucProveedor() +"' ;";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE proveedor SET ciudad_proveedor='"+bnProveedor.getCiudadProveedor()+ "' WHERE ruc_proveedor='"+bnProveedor.getRucProveedor()+"';";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE proveedor SET direccion_proveedor='"+bnProveedor.getDireccionProveedor()+ "' WHERE ruc_proveedor='"+bnProveedor.getRucProveedor()+"';";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE proveedor SET telefono_proveedor='"+bnProveedor.getTelefonoProveedor()+ "' WHERE ruc_proveedor='"+bnProveedor.getRucProveedor()+"';";
                        stmt.executeUpdate(sql);
		stmt.close();
                    JOptionPane.showMessageDialog(null, "Proveedor modificado exitosamente", "Registro de Proveedor",JOptionPane.INFORMATION_MESSAGE); 
                    } 
                    else 
                    {
                        JOptionPane.showMessageDialog(null, "El proveedor a actualizar no existe", "Registro de Proveedor",JOptionPane.INFORMATION_MESSAGE); 
                    }
		cn.close();
	} catch (Exception e) {
		System.err.println(e.getClass().getName() + ": " + e.getMessage());
	}
	//System.out.println("Records updated successfully");

}      
    public int tomarIdProveedor(String nombre)
     {
    	ResultSet rs = null;
		
          int proveedor=0;
		
    	try
    	{
    		
    		cn = Conexion.enlace(cn);
    		Statement sentencia = cn.createStatement();
    		String sql = "select id_proveedor from proveedor where nombre_proveedor='" + nombre+ "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				proveedor=(rs.getInt("id_proveedor"));
				
			}
    		
    	}catch(Exception ex)
    	{
    		JOptionPane.showMessageDialog(null, ex);
    	}
    	
           return proveedor;            
     }
    
	public static void insertarFactura(BeanFactura bf) {

		ResultSet rs = null;

		try {
			cn = Conexion.enlace(cn);
			stmt = cn.createStatement();
			String sql = "SELECT * FROM factura WHERE numero_factura='"
					+ bf.getNumeroFactura() + "' AND proveedor_id_proveedor= '"
					+ bf.getProveedor() + "'";
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				JOptionPane.showMessageDialog(null, "Ya existe una factura con el mismo numero y proveedor",
						"Ingreso de Factura",
						JOptionPane.INFORMATION_MESSAGE);
			} else {
				sql = "INSERT INTO factura (usuario_id_usuario, proveedor_id_proveedor, ano_factura, numero_factura, fecha_factura, mes_factura, total_vivienda, total_alimentacion, total_salud, total_educacion, total_vestimenta, total_otros, total_iva, total_deducibles, total_factura) "
						+ "VALUES ('"
						+ bf.getUsuario()
						+ "','"
						+ bf.getProveedor()
						+ "','"
						+ bf.getAno()
						+ "','"
						+ bf.getNumeroFactura()
						+ "','"
						+ bf.getFechaFactura()
						+ "','"
						+ bf.getMesFactura()
						+ "','"
						+ bf.getTotalVivienda()
						+ "','"
						+ bf.getTotalAlimentacion()
						+ "','"
						+ bf.getTotalSalud()
						+ "','"
						+ bf.getTotalEducacion()
						+ "','"
						+ bf.getTotalVestimenta()
						+ "','"
						+ bf.getTotalOtros()
						+ "','"
						+ bf.getTotalIVA()
						+ "','"
						+ bf.getTotalDeducibles()
						+ "','"
						+ bf.getTotalFactura() + "')";
				stmt.executeUpdate(sql);
				stmt.close();
				JOptionPane.showMessageDialog(null,
						"Factura ingresada exitosamente",
						"Ingreso de nueva Factura",
						JOptionPane.INFORMATION_MESSAGE);
			}
			cn.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			//System.out.println("error ingreso factura");
		}
		//System.out.println("Records of factura created successfully");

	}
	
	public static void eliminarFactura(String numeroFactura,int usuario, int id_proveedor) {

		ResultSet rs = null;

		try {
			
			cn = Conexion.enlace(cn);
			stmt = cn.createStatement();
			String sql = "SELECT * FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND numero_factura='"+ numeroFactura + "' AND proveedor_id_proveedor='"+ id_proveedor + "'"; 
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				sql = "delete from factura where numero_factura='" + numeroFactura
						+ "' AND proveedor_id_proveedor='"+ id_proveedor + "'";
				stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(null,
						"Factura eliminada con exito", "Eliminar Proveedor",
						JOptionPane.INFORMATION_MESSAGE);				

			} else {
				JOptionPane.showMessageDialog(null,
						"No existe esa factura ingresada por este usuario",
						"Eliminar Factura", JOptionPane.INFORMATION_MESSAGE);
			}
			 stmt.close();
			cn.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}
	
    public static void actualizarFactura(BeanFactura bf) {
        
        ResultSet rs = null;
	
            try {
            	cn = Conexion.enlace(cn);
            	stmt = cn.createStatement();
    			String sql = "SELECT * FROM factura WHERE usuario_id_usuario='"
    					+ bf.getUsuario() + "' AND numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "'";  
                rs = stmt.executeQuery(sql);
                    
                    if ( rs.next() ) 
                    {
                        sql = "UPDATE factura SET usuario_id_usuario= '"+ bf.getUsuario() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "' AND proveedor_id_proveedor='"+ bf.getProveedor() + "';";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET proveedor_id_proveedor= '"+ bf.getProveedor() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);                        
                        sql = "UPDATE factura SET ano_factura= '"+ bf.getAno() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "' AND proveedor_id_proveedor='"+ bf.getProveedor() + "';";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET fecha_factura= '"+ bf.getFechaFactura() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET mes_factura= '"+ bf.getMesFactura() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET total_vivienda= '"+ bf.getTotalVivienda() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "' AND proveedor_id_proveedor='"+ bf.getProveedor() + "';";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET total_alimentacion= '"+ bf.getTotalAlimentacion() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET total_salud= '"+ bf.getTotalSalud() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "' AND proveedor_id_proveedor='"+ bf.getProveedor() + "';";
                        stmt.executeUpdate(sql);    
                        sql = "UPDATE factura SET total_educacion= '"+ bf.getTotalEducacion() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql); 
                        sql = "UPDATE factura SET total_vestimenta= '"+ bf.getTotalVestimenta() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET total_otros= '"+ bf.getTotalOtros() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "' AND proveedor_id_proveedor='"+ bf.getProveedor() + "';";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET total_iva= '"+ bf.getTotalIVA() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET total_deducibles= '"+ bf.getTotalDeducibles() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);
                        sql = "UPDATE factura SET total_factura= '"+ bf.getTotalFactura() + "' WHERE numero_factura='"+ bf.getNumeroFactura() + "'AND proveedor_id_proveedor='"+ bf.getProveedor() + "' ;";
                        stmt.executeUpdate(sql);
                        stmt.close();
                    JOptionPane.showMessageDialog(null, "Factura modificada exitosamente", "Modificar Factura",JOptionPane.INFORMATION_MESSAGE); 
                    } 
                    else 
                    {
                        JOptionPane.showMessageDialog(null, "La factura a modificar no existe", "Modificar Factura",JOptionPane.INFORMATION_MESSAGE); 
                    }
		cn.close();
	} catch (Exception e) {
		System.err.println(e.getClass().getName() + ": " + e.getMessage());
	}
	//System.out.println("Records factura updated successfully");

}	

    
	public DefaultTableModel listaFacturas(int usuario, int ano) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			
			String query = "SELECT f.numero_factura as'Factura No.' ,p.nombre_proveedor as 'Proveedor', f.fecha_factura as 'Fecha', f.total_vivienda as 'Vivienda', f.total_alimentacion as 'Alimentacion', f.total_salud as 'Salud', f.total_educacion as 'Educacion', f.total_vestimenta as 'Vestimenta', f.total_otros as 'Otros', f.total_iva as 'IVA factura', f.total_deducibles as 'Total sin IVA', f.total_factura as 'Total con IVA' from factura f, proveedor p WHERE usuario_id_usuario='"
				+ usuario + "' AND f.proveedor_id_proveedor = p.id_proveedor AND ano_factura='"
				+ ano + "'"; 
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}
	
	public DefaultTableModel listaTodasFacturas(int usuario) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			
			String query = "SELECT f.numero_factura as'Factura No.' ,p.nombre_proveedor as 'Proveedor', f.fecha_factura as 'Fecha', f.total_vivienda as 'Vivienda', f.total_alimentacion as 'Alimentacion', f.total_salud as 'Salud', f.total_educacion as 'Educacion', f.total_vestimenta as 'Vestimenta', f.total_otros as 'Otros', f.total_iva as 'IVA factura', f.total_deducibles as 'Total sin IVA', f.total_factura as 'Total con IVA' from factura f, proveedor p WHERE usuario_id_usuario='"
				+ usuario + "' AND f.proveedor_id_proveedor = p.id_proveedor"; 
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}	

	public DefaultTableModel listaTodasFacturasXmesYanio(int usuario,String mes, int anio) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			
			String query = "SELECT f.numero_factura as'Factura No.' ,p.nombre_proveedor as 'Proveedor', f.fecha_factura as 'Fecha', f.total_vivienda as 'Vivienda', f.total_alimentacion as 'Alimentacion', f.total_salud as 'Salud', f.total_educacion as 'Educacion', f.total_vestimenta as 'Vestimenta', f.total_otros as 'Otros', f.total_iva as 'IVA factura', f.total_deducibles as 'Total sin IVA', f.total_factura as 'Total con IVA' from factura f, proveedor p WHERE usuario_id_usuario='"
				+ usuario + "' AND f.proveedor_id_proveedor = p.id_proveedor AND ano_factura='"
				+ anio + "' AND mes_factura='"
				+ mes + "'"; 
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}
	
	
	public DefaultTableModel listaTodasFacturasXmesYanioYproveedor(int usuario,String mes, int anio, String proveedor) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			
			String query = "SELECT f.numero_factura as'Factura No.' ,p.nombre_proveedor as 'Proveedor', f.fecha_factura as 'Fecha', f.total_vivienda as 'Vivienda', f.total_alimentacion as 'Alimentacion', f.total_salud as 'Salud', f.total_educacion as 'Educacion', f.total_vestimenta as 'Vestimenta', f.total_otros as 'Otros', f.total_iva as 'IVA factura', f.total_deducibles as 'Total sin IVA', f.total_factura as 'Total con IVA' from factura f, proveedor p WHERE usuario_id_usuario='"
				+ usuario + "' AND f.proveedor_id_proveedor = p.id_proveedor AND f.ano_factura='"
				+ anio + "' AND f.mes_factura='"
				+ mes + "'AND p.nombre_proveedor='"
				+ proveedor + "'"; 
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}	
	
	public DefaultTableModel listaTodasFacturasXanioYproveedor(int usuario, int anio, String proveedor) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			
			String query = "SELECT f.numero_factura as'Factura No.' ,p.nombre_proveedor as 'Proveedor', f.fecha_factura as 'Fecha', f.total_vivienda as 'Vivienda', f.total_alimentacion as 'Alimentacion', f.total_salud as 'Salud', f.total_educacion as 'Educacion', f.total_vestimenta as 'Vestimenta', f.total_otros as 'Otros', f.total_iva as 'IVA factura', f.total_deducibles as 'Total sin IVA', f.total_factura as 'Total con IVA' from factura f, proveedor p WHERE usuario_id_usuario='"
				+ usuario + "' AND f.proveedor_id_proveedor = p.id_proveedor AND f.ano_factura='"
				+ anio + "'AND p.nombre_proveedor='"
				+ proveedor + "'"; 
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}		
	
	public DefaultTableModel listaAcumuladoXproveedor(int usuario) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			
			String query = "SELECT COUNT(f.proveedor_id_proveedor) as 'Total facturas', p.nombre_proveedor as 'Proveedor', f.ano_factura as 'A�O', SUM(f.total_vivienda) as 'Vivienda', SUM(f.total_alimentacion) as 'Alimentacion', SUM(f.total_salud) as 'Salud', SUM(f.total_educacion) as 'Educacion', SUM(f.total_vestimenta) as 'Vestimenta', SUM(f.total_otros) as 'Otros', SUM(f.total_iva) as 'IVA', SUM(f.total_deducibles) as 'Total sin IVA', SUM(f.total_factura) as 'Total con IVA' FROM factura f LEFT JOIN proveedor p WHERE usuario_id_usuario='"
				+ usuario + "' AND f.proveedor_id_proveedor = p.id_proveedor GROUP BY f.proveedor_id_proveedor, f.ano_factura"; 
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}
	
	public DefaultTableModel listaAcumuladoXproveedorSeleccionado(int usuario, String proveedor) {

		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			ResultSet rs;
			// consuta a mostrar
			
			String query = "SELECT COUNT(f.proveedor_id_proveedor) as 'Total facturas', p.nombre_proveedor as 'Proveedor', f.ano_factura as 'A�O', SUM(f.total_vivienda) as 'Vivienda', SUM(f.total_alimentacion) as 'Alimentacion', SUM(f.total_salud) as 'Salud', SUM(f.total_educacion) as 'Educacion', SUM(f.total_vestimenta) as 'Vestimenta', SUM(f.total_otros) as 'Otros', SUM(f.total_iva) as 'IVA', SUM(f.total_deducibles) as 'Total sin IVA', SUM(f.total_factura) as 'Total con IVA' FROM factura f LEFT JOIN proveedor p WHERE f.usuario_id_usuario='"
				+ usuario + "' AND p.nombre_proveedor='"
				+ proveedor + "' AND f.proveedor_id_proveedor = p.id_proveedor GROUP BY f.proveedor_id_proveedor, f.ano_factura"; 
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		// retornamos modelo para jtable
		return modelo;

	}
	
	
	
	
	
	
	
	
	//TOTALES
    public float totalVivienda(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_vivienda) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }

    public float totalAlimentacion(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_alimentacion) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
    
    public float totalSalud(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_salud) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
    
    public float totalEducacion(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_educacion) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }  
    
    public float totalVestimenta(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_vestimenta) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    } 
    
    public float totalOtros(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_otros) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
    
    public float totalIVA(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_iva) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    } 

    public float totalDeducibles(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_deducibles) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
    
    public float totalFacturas(int usuario, int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(total_factura) AS Total FROM factura WHERE usuario_id_usuario='"
				+ usuario + "' AND ano_factura='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
    
    public float maximoViviendaAnio(int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(maximo_vivienda) AS Total FROM maximos WHERE id_maximo_ano='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
 
    public float maximoAlimentacionAnio(int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(maximo_alimentacion) AS Total FROM maximos WHERE id_maximo_ano='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
  
    public float maximoSaludAnio(int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(maximo_salud) AS Total FROM maximos WHERE id_maximo_ano='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
      
    public float maximoEducacionAnio(int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(maximo_educacion) AS Total FROM maximos WHERE id_maximo_ano='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }    
    
    public float maximoVestimentaAnio(int anio)
    {
   	ResultSet rs = null;		
   	float total=0;
   	try
   	{
   		cn = Conexion.enlace(cn);
   		Statement sentencia = cn.createStatement();
   		String sql = "SELECT SUM(maximo_vestimenta) AS Total FROM maximos WHERE id_maximo_ano='"
				+ anio + "'";
			rs = sentencia.executeQuery(sql);
			while (rs.next()) {
				total=(rs.getInt("Total"));				
			}
			rs.close();
			sentencia.close();
			cn.close();	
	}
   	catch(Exception ex)
   	{
   		JOptionPane.showMessageDialog(null, ex);
   	}
   	return total;            
    }
    
    
	public DefaultTableModel listaAnios() {
		try {
			ResultSet rs = null;
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			// consuta a mostrar
			String query = "SELECT id_maximo_ano AS A�O, maximo_vivienda AS VIVIENDA, maximo_alimentacion AS ALIMENTACION, maximo_salud AS SALUD, maximo_educacion AS EDUCACION, maximo_vestimenta AS VESTIMENTA FROM maximos";
			rs = s.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			// obtenemos numero de columnas
			int CanColumns = rsmd.getColumnCount();
			// comprobamos
			for (int i = 1; i <= CanColumns; i++) {
				// cargamos columnas en modelo
				modelo.addColumn(rsmd.getColumnLabel(i));
			}
			while (rs.next()) {
				// creamos array
				Object[] fila = new Object[CanColumns];
				// cargamos datos a modelo
				for (int i = 0; i < CanColumns; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				modelo.addRow(fila);
			}
			rs.close();
			s.close();
			cn.close();
		} catch (Exception e) {
		}
		return modelo;
	}
	
	public void modificarAnio(int ano, float vivienda, float alimentacion, float salud, float educacion,
			float vestimenta) {
		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			String query = "UPDATE maximos set maximo_alimentacion ='"
					+ alimentacion + "',maximo_salud ='" + salud
					+ "', maximo_vivienda ='" + vivienda + "', maximo_vestimenta ='"
					+ vestimenta + "', maximo_educacion ='" + educacion
					+ "' where id_maximo_ano ='" + ano + "'  ;";
			s.executeUpdate(query);
			s.close();
			cn.close();
			JOptionPane.showMessageDialog(null, "LA ACTUALIZACION SE REALIZO EXITOSAMENTE");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR AL INTENTAR ACTUALIZAR");
		}

	}
	
	public void ingresarAnio(int anio, float limAlim,
			float limEduc, float limSalud, float limVes, float limViv) {

		// dentro de try cacht por si los errores
		try {
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			s = cn.createStatement();
			String query = "INSERT INTO maximos(id_maximo_ano, maximo_alimentacion, maximo_salud, maximo_vivienda, maximo_vestimenta, maximo_educacion)values ('"
					+ anio
					+ "','"
					+ limAlim
					+ "','"
					+ limSalud
					+ "','"
					+ limViv + "','" + limVes + "','" + limEduc + "')";
			s.executeUpdate(query);
			s.close();
			cn.close();
			JOptionPane.showMessageDialog(null, "Datos ingresados exitosamente");
		} catch (Exception e) {
			JOptionPane
					.showMessageDialog(null,
							"EL A�O QUE INTENTA INGRESAR YA EXISTE");
		}
	}
	
	public boolean consultarAnio(int anio) {
		boolean respuesta=false;
		// dentro de try cacht por si los errores
		try {
			ResultSet rs = null;
			cn = Conexion.enlace(cn);
			Statement s = cn.createStatement();
			s = cn.createStatement();
			String query = "SELECT * FROM maximos WHERE id_maximo_ano='"
					+ anio + "'";
			rs=s.executeQuery(query);
			if (rs.next()) {
				respuesta=true;
			}
			else{
				JOptionPane.showMessageDialog(null, "El a�o con el que intenta trabajar aun no tiene registrado sus limites deducibles, por favor ingreselos antes de continuar",
						"",
						JOptionPane.INFORMATION_MESSAGE);
			}
			s.close();
			cn.close();
		} catch (Exception e) {
			JOptionPane
					.showMessageDialog(null,
							"EL A�O QUE INTENTA INGRESAR YA EXISTE");
		}
		return respuesta;
	}
	
	
	public static void eliminarAnio(int anio) {

		ResultSet rs = null;

		try {
			
			cn = Conexion.enlace(cn);
			stmt = cn.createStatement();
			String sql = "SELECT * FROM maximos WHERE id_maximo_ano='"
				+ anio + "'"; 
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				sql = "SELECT * FROM factura WHERE ano_factura='"
						+ anio + "'";
				rs = stmt.executeQuery(sql);
				if (rs.next()) {
					JOptionPane.showMessageDialog(null,
							"El a�o que esta intentando eliminar se encuentra en uso por alguna factura",
							"Eliminar A�o", JOptionPane.INFORMATION_MESSAGE);				
				}
				else
				{
					sql = "delete from maximos where id_maximo_ano='" + anio
							+ "'";
					stmt.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,
							"A�o eliminado exitosamente", "Eliminar A�o",
							JOptionPane.INFORMATION_MESSAGE);	
				}							

			} else {
				JOptionPane.showMessageDialog(null,
						"El a�o que esta intentando eliminar no se encuentra registrado",
						"Eliminar A�o", JOptionPane.INFORMATION_MESSAGE);
			}
			 stmt.close();
			cn.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}
    
}