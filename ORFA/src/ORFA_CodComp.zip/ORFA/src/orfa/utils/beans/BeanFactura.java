package orfa.utils.beans;


import javax.swing.table.DefaultTableModel;

import orfa.core.datos.DatosFactura;

public class BeanFactura {
	String numero_factura;
	String fecha_factura;
	String mes_factura;
	float total_vivienda;
	float total_alimentacion;
	float total_salud;
	float total_educacion;
	float total_vestimenta;
	float total_otros;
	float total_iva;
	float total_deducibles;
	float total_factura;
	//fk
	int usuario;
	int ano;
	int proveedor;

	public String getNumeroFactura() {
		return numero_factura;
	}

	public void setNumeroFactura(String numero_factura) {
		this.numero_factura = numero_factura;
	}

	public String getFechaFactura() {
		return fecha_factura;
	}

	public void setFechaFactura(String fecha_factura) {
		this.fecha_factura = fecha_factura;
	}
	
	public String getMesFactura() {
		return mes_factura;
	}

	public void setMesFactura(String mes_factura) {
		this.mes_factura = mes_factura;
	}

	public float getTotalVivienda() {
		return total_vivienda;
	}

	public void setTotalVivienda(float total_vivienda) {
		this.total_vivienda = total_vivienda;
	}

	public float getTotalAlimentacion() {
		return total_alimentacion;
	}

	public void setTotalAlimentacion(float total_alimentacion) {
		this.total_alimentacion = total_alimentacion;
	}	
	public float getTotalSalud() {
		return total_salud;
	}

	public void setTotalSalud(float total_salud) {
		this.total_salud = total_salud;
	}
	
	public float getTotalEducacion() {
		return total_educacion;
	}

	public void setTotalEducacion(float total_educacion) {
		this.total_educacion = total_educacion;
	}
	
	public float getTotalVestimenta() {
		return total_vestimenta;
	}

	public void setTotalVestimenta(float total_vestimenta) {
		this.total_vestimenta = total_vestimenta;
	}	
	
	public float getTotalOtros() {
		return total_otros;
	}

	public void setTotalOtros(float total_otros) {
		this.total_otros = total_otros;
	}
	
	public float getTotalIVA() {
		return total_iva;
	}

	public void setTotalIVA(float total_iva) {
		this.total_iva = total_iva;
	}	

	public float getTotalDeducibles() {
		return total_deducibles;
	}

	public void setTotalDeducibles(float total_deducibles) {
		this.total_deducibles = total_deducibles;
	}
	
	public float getTotalFactura() {
		return total_factura;
	}

	public void setTotalFactura(float total_factura) {
		this.total_factura = total_factura;
	}	
	
	public int getUsuario() {
		return usuario;
	}

	public void setUsuario(int usuario) {
		this.usuario = usuario;
	}

	
	public int getProveedor() {
		return proveedor;
	}

	public void setProveedor(int proveedor) {
		this.proveedor = proveedor;
	}
	
	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}	


	public DefaultTableModel lista2(int numero_factura) {

		DatosFactura df = new DatosFactura();
		return df.lista(numero_factura);
	}

}